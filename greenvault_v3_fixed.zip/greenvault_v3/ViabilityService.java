import java.sql.SQLException;
import java.util.*;

public class ViabilityService {

    // Predicts germination % after 'daysAhead' days. Uses the slope between the first and last
    // germination tests; with fewer than 2 tests it assumes 100% at collection and a straight-line decay.
    public static double predict(int batchId, double current, double ageDays, int daysAhead) throws SQLException {
        List<Object[]> t = Db.query("SELECT t.test_date - b.collected_date, t.rate FROM germination_test t "
                + "JOIN seed_batch b ON b.batch_id = t.batch_id WHERE t.batch_id = ? ORDER BY t.test_date", batchId);
        double slope = (current - 100) / Math.max(ageDays, 90);   // age floor of 90 days stops fresh batches looking like they collapse
        if (t.size() >= 2) {
            Object[] first = t.get(0), last = t.get(t.size() - 1);
            double days = Theme.num(last[0]) - Theme.num(first[0]);
            if (days > 0) slope = (Theme.num(last[1]) - Theme.num(first[1])) / days;
        }
        slope = Math.min(0, slope);
        return Math.max(0, current + slope * daysAhead);
    }

    // Batches that are, or soon will be, below the threshold
    public static List<String> warnings(int days, double threshold) throws SQLException {
        List<String> out = new ArrayList<>();
        for (Object[] r : Db.query("SELECT b.batch_id, v.name, b.germination_rate, TRUNC(SYSDATE - b.collected_date) "
                + "FROM seed_batch b JOIN seed_variety v ON v.seed_id = b.seed_id WHERE b.quantity_kg > 0")) {
            int id = (int) Theme.num(r[0]);
            double g = Theme.num(r[2]), p = predict(id, g, Theme.num(r[3]), days);
            if (g < threshold) out.add(r[1] + " batch " + id + " is already at " + (int) g + "% - use or regenerate it");
            else if (p < threshold) out.add(r[1] + " batch " + id + ": " + (int) g + "% now, about " + (int) p + "% in " + days + " days");
        }
        return out;
    }
}
