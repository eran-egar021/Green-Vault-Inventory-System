import javax.swing.*;
import javax.swing.border.*;
import javax.swing.plaf.FontUIResource;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.geom.*;
import java.awt.image.BufferedImage;
import java.util.Enumeration;
import java.util.List;

public class Theme {
    // Earthy seed-packet palette (names kept so every panel picks it up automatically)
    public static final Color DARK = new Color(0x2F5D3A), MID = new Color(0x4F7C43), LIGHT = new Color(0xE9DFC6),
            BG = new Color(0xF1E8D4), TEXT = new Color(0x4A3322), WARN = new Color(0xB0472B),
            PACKET = new Color(0xFBF6EA), KRAFT = new Color(0x7A5230), OCHRE = new Color(0xC9953C),
            MOSS = new Color(0x6B8F4E), CLAY = new Color(0x9C5B3B), LINE = new Color(0xD8CBAA);
    public static final Font BASE = new Font("Segoe UI", Font.PLAIN, 14), BOLD = BASE.deriveFont(Font.BOLD),
            HEAD = new Font("Georgia", Font.BOLD, 22);

    public static void apply() {
        try { UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName()); } catch (Exception ignored) { }
        for (Enumeration<Object> k = UIManager.getDefaults().keys(); k.hasMoreElements();) {
            Object key = k.nextElement();
            if (UIManager.get(key) instanceof Font) UIManager.put(key, new FontUIResource(BASE));
        }
        UIManager.put("Panel.background", BG);
        UIManager.put("OptionPane.background", BG);
        UIManager.put("OptionPane.messageForeground", TEXT);
        UIManager.put("Label.foreground", TEXT);
        UIManager.put("Table.background", PACKET);
        UIManager.put("TextArea.background", PACKET);
        UIManager.put("TextField.background", Color.WHITE);
    }

    // Leaf logo drawn in code, so no image files are needed
    public static Icon logo(int s) {
        BufferedImage img = new BufferedImage(s, s, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = img.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setColor(PACKET); g.fillOval(0, 0, s, s);
        g.setColor(MID);
        Path2D leaf = new Path2D.Double();
        leaf.moveTo(s * 0.25, s * 0.75);
        leaf.curveTo(s * 0.2, s * 0.3, s * 0.6, s * 0.2, s * 0.78, s * 0.22);
        leaf.curveTo(s * 0.8, s * 0.6, s * 0.55, s * 0.82, s * 0.25, s * 0.75);
        g.fill(leaf);
        g.setColor(PACKET); g.setStroke(new BasicStroke(Math.max(1.5f, s * 0.03f)));
        g.draw(new Line2D.Double(s * 0.27, s * 0.73, s * 0.65, s * 0.35));
        g.dispose();
        return new ImageIcon(img);
    }

    public static JButton button(String text, ActionListener l) {
        JButton b = new JButton(text);
        b.setBackground(DARK); b.setForeground(PACKET); b.setFont(BOLD);
        b.setFocusPainted(false); b.setOpaque(true); b.setBorder(new EmptyBorder(8, 16, 8, 16));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        if (l != null) b.addActionListener(l);
        return b;
    }

    public static JLabel title(String t) {
        JLabel l = new JLabel(t);
        l.setFont(HEAD); l.setForeground(DARK);
        l.setBorder(new EmptyBorder(0, 0, 10, 0));
        return l;
    }

    public static JPanel card(String label, String value) {
        JPanel p = new JPanel(new GridLayout(2, 1));
        p.setBackground(PACKET);
        p.setBorder(new CompoundBorder(new LineBorder(LINE), new EmptyBorder(12, 16, 12, 16)));
        JLabel v = new JLabel(value); v.setFont(new Font("Georgia", Font.BOLD, 26)); v.setForeground(DARK);
        JLabel l = new JLabel(label); l.setForeground(KRAFT);
        p.add(v); p.add(l);
        return p;
    }

    public static DefaultTableModel model(String... cols) {
        return new DefaultTableModel(cols, 0) { @Override public boolean isCellEditable(int r, int c) { return false; } };
    }

    public static void style(JTable t) {
        t.setRowHeight(26);
        t.setGridColor(LINE); t.setBackground(PACKET); t.setForeground(TEXT);
        t.setSelectionBackground(new Color(0xE3D4AE)); t.setSelectionForeground(TEXT);
        t.getTableHeader().setBackground(DARK); t.getTableHeader().setForeground(PACKET); t.getTableHeader().setFont(BOLD);
        t.setAutoCreateRowSorter(true);
    }

    public static void fill(DefaultTableModel m, List<Object[]> rows) { m.setRowCount(0); for (Object[] r : rows) m.addRow(r); }
    public static void msg(java.awt.Component c, String s) { JOptionPane.showMessageDialog(c, s); }
    public static void error(java.awt.Component c, Exception e) { JOptionPane.showMessageDialog(c, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE); }
    public static double num(Object o) { return ((Number) o).doubleValue(); }
}
