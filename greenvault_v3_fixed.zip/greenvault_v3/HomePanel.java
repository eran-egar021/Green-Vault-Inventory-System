import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.AffineTransform;
import java.awt.geom.Path2D;
import java.awt.geom.RoundRectangle2D;

// Card-grid home: big seed-packet tiles, all pictures drawn in code (no image files)
public class HomePanel extends JPanel {
    public enum Icon { LEAF, SEARCH, BOX, CLIPBOARD, THERMO, TREND, LIST }

    private final JPanel grid = new JPanel(new GridLayout(0, 3, 26, 26));

    public HomePanel() {
        setLayout(new BorderLayout());
        setBackground(Theme.BG);
        setBorder(new EmptyBorder(24, 36, 24, 36));

        JPanel welcome = new JPanel();
        welcome.setOpaque(false);
        welcome.setLayout(new BoxLayout(welcome, BoxLayout.Y_AXIS));
        JLabel hello = new JLabel("Welcome, " + Me.name);
        hello.setFont(new Font("Georgia", Font.BOLD, 26)); hello.setForeground(Theme.TEXT);
        JLabel sub = new JLabel("Signed in as " + Me.role + ". Choose a section to begin.");
        sub.setForeground(Theme.KRAFT);
        welcome.add(hello); welcome.add(Box.createVerticalStrut(4)); welcome.add(sub);
        welcome.setBorder(new EmptyBorder(0, 0, 20, 0));
        add(welcome, BorderLayout.NORTH);

        grid.setOpaque(false);
        JPanel top = new JPanel(new BorderLayout());
        top.setOpaque(false);
        top.add(grid, BorderLayout.NORTH);
        JScrollPane sp = new JScrollPane(top);
        sp.setBorder(null); sp.setOpaque(false); sp.getViewport().setOpaque(false);
        sp.getVerticalScrollBar().setUnitIncrement(16);
        add(sp, BorderLayout.CENTER);
    }

    public void addTile(String title, String subtitle, Icon icon, Color accent, Runnable action) {
        grid.add(new Tile(title, subtitle, icon, accent, action));
    }

    // ---------- One seed-packet tile ----------
    static class Tile extends JPanel {
        private final String title, subtitle;
        private final Icon icon;
        private final Color accent;
        private boolean hover;

        Tile(String title, String subtitle, Icon icon, Color accent, Runnable action) {
            this.title = title; this.subtitle = subtitle; this.icon = icon; this.accent = accent;
            setOpaque(false);
            setPreferredSize(new Dimension(250, 200));
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            addMouseListener(new MouseAdapter() {
                @Override public void mouseEntered(MouseEvent e) { hover = true; repaint(); }
                @Override public void mouseExited(MouseEvent e) { hover = false; repaint(); }
                @Override public void mouseClicked(MouseEvent e) { action.run(); }
            });
        }

        @Override protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create();
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            int w = getWidth() - 10, h = getHeight() - 12, y = hover ? 0 : 5;

            g.setColor(new Color(0x4A, 0x33, 0x22, hover ? 70 : 40));
            g.fillRoundRect(6, y + 8, w, h, 14, 14);
            g.setColor(Theme.PACKET);
            g.fillRoundRect(0, y, w, h, 14, 14);
            g.setColor(Theme.LINE);
            g.drawRoundRect(0, y, w, h, 14, 14);

            // crimped top band
            Shape old = g.getClip();
            g.setClip(new RoundRectangle2D.Float(0, y, w, h, 14, 14));
            g.setColor(accent);
            g.fillRect(0, y, w, 38);
            for (int x = 0; x < w; x += 12)
                g.fillPolygon(new Polygon(new int[]{x, x + 12, x + 6}, new int[]{y + 38, y + 38, y + 45}, 3));
            g.setClip(old);

            int cx = w / 2, cy = y + 88;
            g.setColor(Theme.BG); g.fillOval(cx - 34, cy - 34, 68, 68);
            g.setColor(accent); g.setStroke(new BasicStroke(2f)); g.drawOval(cx - 34, cy - 34, 68, 68);
            drawIcon(g, icon, cx, cy, accent);

            g.setFont(new Font("Georgia", Font.BOLD, 16)); g.setColor(Theme.TEXT);
            FontMetrics fm = g.getFontMetrics();
            g.drawString(title, cx - fm.stringWidth(title) / 2, y + 152);
            g.setFont(Theme.BASE.deriveFont(13f)); g.setColor(Theme.KRAFT);
            fm = g.getFontMetrics();
            g.drawString(subtitle, cx - fm.stringWidth(subtitle) / 2, y + 173);
            g.dispose();
        }
    }

    // ---------- Drawn pictures ----------
    public static void leaf(Graphics2D g, int x, int y, int size, double angleDeg, Color c) {
        AffineTransform old = g.getTransform();
        g.translate(x, y); g.rotate(Math.toRadians(angleDeg));
        Path2D p = new Path2D.Double();
        p.moveTo(0, 0);
        p.quadTo(size * 0.5, -size * 0.9, size * 1.6, 0);
        p.quadTo(size * 0.5, size * 0.9, 0, 0);
        g.setColor(c); g.fill(p);
        g.setTransform(old);
    }

    // Row of sprouts used on the header and the welcome screen
    public static void sprouts(Graphics2D g, int rightEdge, int baseY, int count) {
        g.setStroke(new BasicStroke(3f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        for (int i = 0; i < count; i++) {
            int x = rightEdge - 40 - i * 46, h = 34 + (i % 3) * 14;
            Color c = i % 2 == 0 ? Theme.MOSS : new Color(0x4F7C43);
            g.setColor(c);
            g.drawLine(x, baseY, x, baseY - h);
            leaf(g, x, baseY - h, 16, -35, c);
            leaf(g, x, baseY - h + 12, 13, 215, c);
        }
    }

    static void drawIcon(Graphics2D g, Icon type, int cx, int cy, Color c) {
        AffineTransform old = g.getTransform();
        g.translate(cx, cy);
        g.setColor(c);
        g.setStroke(new BasicStroke(3f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        switch (type) {
            case LEAF: {
                Path2D p = new Path2D.Double();
                p.moveTo(-16, 16); p.quadTo(-22, -20, 16, -18); p.quadTo(20, 18, -16, 16);
                g.fill(p);
                g.setColor(Theme.PACKET); g.setStroke(new BasicStroke(2f));
                g.drawLine(-14, 14, 8, -8);
                break;
            }
            case SEARCH:
                g.drawOval(-15, -15, 22, 22);
                g.setStroke(new BasicStroke(5f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                g.drawLine(5, 5, 16, 16);
                break;
            case BOX:
                g.fillRect(-17, -4, 34, 22); g.fillRect(-21, -14, 42, 9);
                g.setColor(Theme.PACKET); g.fillRect(-6, 3, 12, 4);
                break;
            case CLIPBOARD:
                g.fillRoundRect(-14, -18, 28, 36, 6, 6);
                g.setColor(Theme.PACKET); g.fillRect(-6, -21, 12, 7);
                g.setStroke(new BasicStroke(2f));
                g.drawLine(-8, -3, 8, -3); g.drawLine(-8, 4, 8, 4); g.drawLine(-8, 11, 3, 11);
                break;
            case THERMO:
                g.fillRoundRect(-5, -20, 10, 28, 10, 10);
                g.fillOval(-11, 3, 22, 22);
                g.setColor(Theme.PACKET); g.fillRoundRect(-2, -14, 4, 22, 4, 4); g.fillOval(-6, 8, 12, 12);
                break;
            case TREND:
                g.drawPolyline(new int[]{-18, -6, 3, 17}, new int[]{12, 0, 6, -12}, 4);
                g.fillPolygon(new int[]{20, 8, 18}, new int[]{-16, -14, -4}, 3);
                break;
            case LIST:
                g.fillRoundRect(-16, -18, 32, 36, 6, 6);
                g.setColor(Theme.PACKET); g.setStroke(new BasicStroke(2.5f));
                g.drawLine(-9, -9, 9, -9); g.drawLine(-9, 0, 9, 0); g.drawLine(-9, 9, 4, 9);
                break;
        }
        g.setTransform(old);
    }
}
