import java.util.*;
import java.util.stream.Collectors;

public class RecommendationService {
    private static final List<String> WATER = Arrays.asList("low", "medium", "high");

    // Scores out of 100: temp 25, soil 20, season 15, water 10, sunlight 10, pH 10, humidity 10
    // plus a farmer-feedback adjustment (-10..+10) and an expiry penalty
    public static List<Seed> recommend(List<Seed> seeds, double temp, double hum, double ph, String soil, String sunlight,
                                       String season, String water, String district, Map<Integer, Double> feedback) {
        for (Seed s : seeds) {
            int score = 0;
            List<String> why = new ArrayList<>();

            if (temp >= s.minTemp && temp <= s.maxTemp) { score += 25; why.add("temperature fits"); }
            else if (temp >= s.minTemp - 3 && temp <= s.maxTemp + 3) { score += 12; why.add("temperature close"); }

            if (hum >= s.minHum && hum <= s.maxHum) { score += 10; why.add("humidity fits"); }
            else if (hum >= s.minHum - 10 && hum <= s.maxHum + 10) { score += 5; }

            if (s.soil.equalsIgnoreCase(soil)) { score += 20; why.add(soil + " soil"); }
            if (s.season.equalsIgnoreCase(season)) { score += 15; why.add("ideal for " + season); }

            int diff = Math.abs(WATER.indexOf(s.water.toLowerCase()) - WATER.indexOf(water.toLowerCase()));
            if (diff == 0) { score += 10; why.add("water need matches"); } else if (diff == 1) { score += 5; }

            if (s.sunlight.equalsIgnoreCase(sunlight)) { score += 10; why.add(sunlight.toLowerCase() + " sunlight"); }
            if (ph >= s.minPh && ph <= s.maxPh) { score += 10; why.add("pH in range"); }

            Double avg = feedback.get(s.seedId);
            if (avg != null) {
                score += (int) Math.round((avg - 3) * 5);
                why.add(String.format("rated %.1f/5 in %s", avg, district));
            }
            if (s.daysToExpiry <= 30) { score -= 10; why.add("batch expiring soon"); }
            if (s.rare) why.add("rare variety - limited quantity");

            s.score = Math.max(0, Math.min(100, score));
            s.reason = String.join(", ", why);
        }
        return seeds.stream().filter(s -> s.score >= 40)
                .sorted((a, b) -> b.score != a.score ? b.score - a.score : b.germination - a.germination)
                .limit(5).collect(Collectors.toList());
    }
}
