import javax.swing.*;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;

public class WelcomeFrame extends JFrame {
    private final CardLayout cards = new CardLayout();
    private final JPanel right = new JPanel(cards);
    private final JTextField lUser = new JTextField();
    private final JPasswordField lPass = new JPasswordField();
    private final JTextField rUser = new JTextField(), rName = new JTextField(), rMail = new JTextField();
    private final JPasswordField rPass = new JPasswordField();

    public WelcomeFrame() {
        setTitle("GreenVault Seed Inventory System");
        setSize(860, 520); setResizable(false); setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new GridLayout(1, 2));

        JPanel left = new JPanel(new GridBagLayout()) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(Theme.DARK); g2.fillRect(0, 0, getWidth(), getHeight());
                HomePanel.sprouts(g2, getWidth() + 20, getHeight() - 8, 9);
                g2.setColor(Theme.OCHRE); g2.fillRect(getWidth() - 5, 0, 5, getHeight());
                g2.dispose();
            }
        };
        JPanel box = new JPanel();
        box.setOpaque(false); box.setLayout(new BoxLayout(box, BoxLayout.Y_AXIS));
        JLabel logo = new JLabel(Theme.logo(110));
        logo.setAlignmentX(CENTER_ALIGNMENT);
        box.add(logo); box.add(Box.createVerticalStrut(16));
        box.add(white("GreenVault", 34, true));
        box.add(white("Seed Inventory System", 16, false));
        box.add(Box.createVerticalStrut(10));
        box.add(white("Store smart. Grow right.", 13, false));
        left.add(box);

        JButton goLogin = Theme.button("Login", e -> login());
        JButton toRegister = link("New here? Create an account", () -> cards.show(right, "register"));
        right.add(form("Welcome back", new String[]{"Username", "Password"}, new JComponent[]{lUser, lPass}, goLogin, toRegister), "login");

        JButton goRegister = Theme.button("Register", e -> register());
        JButton toLogin = link("Already registered? Login", () -> cards.show(right, "login"));
        right.add(form("Create account", new String[]{"Full name", "Email", "Username", "Password (6+ characters)"},
                new JComponent[]{rName, rMail, rUser, rPass}, goRegister, toLogin), "register");

        add(left); add(right);
        getRootPane().setDefaultButton(goLogin);
    }

    private static JLabel white(String text, int size, boolean bold) {
        JLabel l = new JLabel(text);
        l.setForeground(Theme.PACKET);
        l.setFont(bold ? new Font("Georgia", Font.BOLD, size) : Theme.BASE.deriveFont(Font.PLAIN, (float) size));
        l.setAlignmentX(CENTER_ALIGNMENT);
        return l;
    }

    private JButton link(String text, Runnable r) {
        JButton b = new JButton(text);
        b.setBorderPainted(false); b.setContentAreaFilled(false); b.setFocusPainted(false);
        b.setForeground(Theme.KRAFT); b.setAlignmentX(LEFT_ALIGNMENT);
        b.addActionListener(e -> r.run());
        return b;
    }

    private JPanel form(String heading, String[] labels, JComponent[] fields, JButton go, JButton alt) {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setBorder(BorderFactory.createEmptyBorder(40, 50, 40, 50));
        JLabel t = Theme.title(heading);
        t.setAlignmentX(LEFT_ALIGNMENT);
        p.add(t);
        for (int i = 0; i < labels.length; i++) {
            JLabel l = new JLabel(labels[i]);
            l.setAlignmentX(LEFT_ALIGNMENT);
            fields[i].setAlignmentX(LEFT_ALIGNMENT);
            fields[i].setMaximumSize(new Dimension(Integer.MAX_VALUE, 32));
            p.add(l); p.add(fields[i]); p.add(Box.createVerticalStrut(10));
        }
        go.setAlignmentX(LEFT_ALIGNMENT);
        p.add(Box.createVerticalStrut(6)); p.add(go); p.add(Box.createVerticalStrut(8)); p.add(alt);
        return p;
    }

    private void login() {
        String u = lUser.getText().trim().toLowerCase();
        try {
            List<Object[]> r = Db.query("SELECT user_id, full_name, role, email FROM app_user WHERE username = ? AND password_hash = ?",
                    u, Security.hash(u, new String(lPass.getPassword())));
            if (r.isEmpty()) { Theme.msg(this, "Invalid username or password."); return; }
            Me.id = (int) Theme.num(r.get(0)[0]);
            Me.name = (String) r.get(0)[1]; Me.role = (String) r.get(0)[2]; Me.email = (String) r.get(0)[3];
            dispose();
            new MainFrame().setVisible(true);
        } catch (SQLException e) { Theme.error(this, e); }
    }

    private void register() {
        String u = rUser.getText().trim().toLowerCase(), p = new String(rPass.getPassword());
        if (u.isEmpty() || rName.getText().trim().isEmpty() || p.length() < 6) {
            Theme.msg(this, "Fill every field. The password needs at least 6 characters.");
            return;
        }
        try {
            if (!Db.query("SELECT 1 FROM app_user WHERE username = ?", u).isEmpty()) { Theme.msg(this, "That username is taken."); return; }
            Db.exec("INSERT INTO app_user (user_id, username, password_hash, full_name, email, role) VALUES (seq_id.NEXTVAL, ?, ?, ?, ?, 'CLIENT')",
                    u, Security.hash(u, p), rName.getText().trim(), rMail.getText().trim());
            Theme.msg(this, "Registered! Please log in.");
            cards.show(right, "login");
        } catch (SQLException e) { Theme.error(this, e); }
    }

    public static void main(String[] args) {
        Theme.apply();
        SwingUtilities.invokeLater(() -> new WelcomeFrame().setVisible(true));
    }
}
