import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;

public class RequestsPanel extends JPanel {
    private final boolean staff = !Me.role.equals("CLIENT");
    private final DefaultTableModel model = Theme.model("Request", "Client", "Seed", "Batch", "Qty (kg)", "Status", "Date");
    private final JTable table = new JTable(model);

    public RequestsPanel() {
        setLayout(new BorderLayout(0, 10)); setOpaque(false);
        add(Theme.title(staff ? "Seed Requests" : "My Requests"), BorderLayout.NORTH);
        Theme.style(table);
        add(new JScrollPane(table), BorderLayout.CENTER);
        JPanel bar = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        bar.setOpaque(false);
        if (staff) {
            bar.add(Theme.button("Approve", e -> decide("APPROVED")));
            bar.add(Theme.button("Reject", e -> decide("REJECTED")));
        } else {
            bar.add(Theme.button("Give feedback on approved seed", e -> feedback()));
        }
        add(bar, BorderLayout.SOUTH);
        load();
    }

    private void load() {
        String sql = "SELECT r.request_id, u.full_name, v.name, r.batch_id, r.qty_kg, r.status, TO_CHAR(r.request_date,'DD-MM-YYYY') "
                + "FROM seed_request r JOIN app_user u ON u.user_id = r.client_id JOIN seed_batch b ON b.batch_id = r.batch_id "
                + "JOIN seed_variety v ON v.seed_id = b.seed_id ";
        try {
            if (staff) Theme.fill(model, Db.query(sql + "ORDER BY r.request_id DESC"));
            else Theme.fill(model, Db.query(sql + "WHERE r.client_id = ? ORDER BY r.request_id DESC", Me.id));
        } catch (SQLException e) { Theme.error(this, e); }
    }

    private int selectedRow() {
        int r = table.getSelectedRow();
        if (r < 0) { Theme.msg(this, "Select a request first."); return -1; }
        return table.convertRowIndexToModel(r);
    }

    // Uses the stored procedure; the trigger deducts stock
    private void decide(String decision) {
        int r = selectedRow();
        if (r < 0) return;
        int id = (int) Theme.num(model.getValueAt(r, 0));
        try {
            Db.call("{call sp_decide_request(?, ?)}", id, decision);
            load();
        } catch (SQLException e) { Theme.error(this, e); }
    }

    // Feedback learning loop: ratings feed the recommender for that district
    private void feedback() {
        int r = selectedRow();
        if (r < 0) return;
        if (!"APPROVED".equals(model.getValueAt(r, 5))) { Theme.msg(this, "You can rate a request once it is approved."); return; }
        int id = (int) Theme.num(model.getValueAt(r, 0));
        try {
            if (!Db.query("SELECT 1 FROM feedback WHERE request_id = ?", id).isEmpty()) { Theme.msg(this, "Feedback already submitted."); return; }
            JComboBox<String> dist = new JComboBox<>();
            for (Object[] d : Db.query("SELECT district FROM region ORDER BY district")) dist.addItem((String) d[0]);
            JComboBox<Integer> rating = new JComboBox<>(new Integer[]{5, 4, 3, 2, 1});
            JTextField note = new JTextField();
            Object[] form = {"Where did you grow it?", dist, "Rating (5 = excellent yield)", rating, "Comments", note};
            if (JOptionPane.showConfirmDialog(this, form, "Seed feedback", JOptionPane.OK_CANCEL_OPTION) != JOptionPane.OK_OPTION) return;
            Object seedId = Db.query("SELECT b.seed_id FROM seed_request r JOIN seed_batch b ON b.batch_id = r.batch_id WHERE r.request_id = ?", id).get(0)[0];
            Db.exec("INSERT INTO feedback (feedback_id, request_id, client_id, seed_id, district, rating, remarks) VALUES (seq_id.NEXTVAL, ?, ?, ?, ?, ?, ?)",
                    id, Me.id, seedId, dist.getSelectedItem(), rating.getSelectedItem(), note.getText().trim());
            Theme.msg(this, "Thanks! Your rating will improve future recommendations.");
        } catch (SQLException e) { Theme.error(this, e); }
    }
}
