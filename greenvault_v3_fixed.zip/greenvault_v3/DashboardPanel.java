import javax.swing.*;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;

public class DashboardPanel extends JPanel {
    public DashboardPanel() {
        setLayout(new BorderLayout(0, 12)); setOpaque(false);
        add(Theme.title("Welcome, " + Me.name), BorderLayout.NORTH);
        try {
            boolean client = Me.role.equals("CLIENT");
            JPanel cards = new JPanel(new GridLayout(1, 4, 12, 0));
            cards.setOpaque(false);
            cards.add(Theme.card("Seed varieties", Db.one("SELECT COUNT(*) FROM seed_variety")));
            cards.add(Theme.card("Total stock (kg)", Db.one("SELECT NVL(SUM(quantity_kg),0) FROM seed_batch")));
            cards.add(Theme.card(client ? "My pending requests" : "Pending requests",
                    client ? Db.one("SELECT COUNT(*) FROM seed_request WHERE status='PENDING' AND client_id = ?", Me.id)
                           : Db.one("SELECT COUNT(*) FROM seed_request WHERE status='PENDING'")));
            cards.add(Theme.card("Expiring in 30 days",
                    Db.one("SELECT COUNT(*) FROM seed_batch WHERE quantity_kg > 0 AND expiry_date BETWEEN SYSDATE AND SYSDATE + 30")));

            List<Object[]> stock = Db.query("SELECT name, total_kg FROM v_stock ORDER BY total_kg DESC");
            int shown = Math.min(stock.size(), 8);   // top 8 only, so 200+ varieties stay readable
            String[] labels = new String[shown];
            double[] values = new double[shown];
            for (int i = 0; i < shown; i++) { labels[i] = (String) stock.get(i)[0]; values[i] = Theme.num(stock.get(i)[1]); }

            StringBuilder a = new StringBuilder();
            for (Object[] r : Db.query("SELECT v.name, b.batch_id, TRUNC(b.expiry_date - SYSDATE) FROM seed_batch b "
                    + "JOIN seed_variety v ON v.seed_id = b.seed_id WHERE b.quantity_kg > 0 AND b.expiry_date BETWEEN SYSDATE AND SYSDATE + 30"))
                a.append("EXPIRY: ").append(r[0]).append(" batch ").append(r[1]).append(" - ").append(r[2]).append(" days left\n\n");
            for (Object[] r : Db.query("SELECT name, total_kg, reorder_level FROM v_stock WHERE total_kg < reorder_level"))
                a.append("LOW STOCK: ").append(r[0]).append(" - ").append(r[1]).append(" kg (minimum ").append(r[2]).append(")\n\n");
            for (String w : ViabilityService.warnings(90, 70)) a.append("VIABILITY: ").append(w).append("\n\n");
            if (a.length() == 0) a.append("No alerts. Everything looks healthy.");

            JTextArea alerts = new JTextArea(a.toString());
            alerts.setEditable(false); alerts.setLineWrap(true); alerts.setWrapStyleWord(true);
            JScrollPane sp = new JScrollPane(alerts);
            sp.setBorder(BorderFactory.createTitledBorder("Alerts"));

            JPanel mid = new JPanel(new GridLayout(1, 2, 12, 0));
            mid.setOpaque(false);
            mid.add(new BarChart("Top 8 varieties by stock (kg)", labels, values));
            mid.add(sp);

            JPanel body = new JPanel(new BorderLayout(0, 12));
            body.setOpaque(false);
            body.add(cards, BorderLayout.NORTH);
            body.add(mid, BorderLayout.CENTER);
            add(body, BorderLayout.CENTER);
        } catch (SQLException e) { add(new JLabel("Database error: " + e.getMessage()), BorderLayout.CENTER); }
    }
}
