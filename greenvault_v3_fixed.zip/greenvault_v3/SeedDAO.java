import java.sql.SQLException;
import java.util.*;

public class SeedDAO {
    private static double d(Object o) { return ((Number) o).doubleValue(); }

    // In-stock, unexpired batches with germination >= 50%
    public static List<Seed> getAvailable() throws SQLException {
        String sql = "SELECT b.batch_id, v.seed_id, v.name, v.min_temp, v.max_temp, v.min_hum, v.max_hum, v.min_ph, v.max_ph, "
                   + "v.soil_type, v.sunlight, v.season, v.water_need, v.days_to_harvest, v.is_rare, v.max_request_kg, "
                   + "b.quantity_kg, b.germination_rate, TRUNC(b.expiry_date - SYSDATE) "
                   + "FROM seed_batch b JOIN seed_variety v ON v.seed_id = b.seed_id "
                   + "WHERE b.quantity_kg > 0 AND b.expiry_date > SYSDATE AND b.germination_rate >= 50";
        List<Seed> list = new ArrayList<>();
        for (Object[] r : Db.query(sql)) {
            Seed s = new Seed();
            s.batchId = (int) d(r[0]); s.seedId = (int) d(r[1]); s.name = (String) r[2];
            s.minTemp = d(r[3]); s.maxTemp = d(r[4]); s.minHum = d(r[5]); s.maxHum = d(r[6]);
            s.minPh = d(r[7]); s.maxPh = d(r[8]);
            s.soil = (String) r[9]; s.sunlight = (String) r[10]; s.season = (String) r[11]; s.water = (String) r[12];
            s.daysToHarvest = (int) d(r[13]); s.rare = "Y".equals(r[14]); s.maxRequestKg = d(r[15]);
            s.stockKg = d(r[16]); s.germination = (int) d(r[17]); s.daysToExpiry = (int) d(r[18]);
            list.add(s);
        }
        return list;
    }

    // Average farmer rating per seed in a district (feedback learning loop)
    public static Map<Integer, Double> feedback(String district) throws SQLException {
        Map<Integer, Double> m = new HashMap<>();
        for (Object[] r : Db.query("SELECT seed_id, AVG(rating) FROM feedback WHERE district = ? GROUP BY seed_id", district))
            m.put((int) d(r[0]), d(r[1]));
        return m;
    }
}
