import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;

public class AuditPanel extends JPanel {
    public AuditPanel() {
        setLayout(new BorderLayout(0, 10)); setOpaque(false);
        add(Theme.title("Audit Log"), BorderLayout.NORTH);
        DefaultTableModel m = Theme.model("ID", "When", "Table", "Action", "By", "Details");
        JTable t = new JTable(m);
        Theme.style(t);
        try {
            Theme.fill(m, Db.query("SELECT * FROM (SELECT log_id, TO_CHAR(changed_on,'DD-MM-YYYY HH24:MI'), table_name, action, changed_by, details "
                    + "FROM audit_log ORDER BY log_id DESC) WHERE ROWNUM <= 200"));
        } catch (SQLException e) { Theme.error(this, e); }
        JPanel bar = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        bar.setOpaque(false);
        bar.add(Theme.button("Export Excel", e -> Exporter.csv(this, t)));
        bar.add(Theme.button("Print / PDF", e -> Exporter.print(this, t)));
        add(new JScrollPane(t), BorderLayout.CENTER);
        add(bar, BorderLayout.SOUTH);
    }
}
