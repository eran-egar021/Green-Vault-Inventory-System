import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.List;

public class FindSeedPanel extends JPanel {
    private final JComboBox<String> district = new JComboBox<>();
    private final JSpinner temp = new JSpinner(new SpinnerNumberModel(28.0, 0.0, 50.0, 1.0));
    private final JSpinner hum = new JSpinner(new SpinnerNumberModel(60.0, 10.0, 100.0, 5.0));
    private final JSpinner ph = new JSpinner(new SpinnerNumberModel(6.5, 3.0, 10.0, 0.1));
    private final JComboBox<String> soil = new JComboBox<>(new String[]{"Loamy", "Clay", "Sandy", "Black", "Red"});
    private final JComboBox<String> sunlight = new JComboBox<>(new String[]{"Full", "Partial"});
    private final JComboBox<String> season = new JComboBox<>(new String[]{"Kharif", "Rabi", "Summer"});
    private final JComboBox<String> water = new JComboBox<>(new String[]{"Low", "Medium", "High"});
    private final JLabel info = new JLabel("Pick your district and auto-fill the temperature, or enter conditions manually.");
    private final DefaultTableModel model = Theme.model("Seed", "Batch", "Match %", "Viability", "Stock (kg)", "Harvest (days)", "Why recommended");
    private final JTable table = new JTable(model);
    private final JTextArea notes = new JTextArea(4, 40);
    private final Map<String, double[]> regions = new HashMap<>();
    private List<Seed> results = new ArrayList<>();

    public FindSeedPanel() {
        setLayout(new BorderLayout(0, 10)); setOpaque(false);
        try {
            for (Object[] r : Db.query("SELECT district, latitude, longitude, avg_temp FROM region ORDER BY district")) {
                district.addItem((String) r[0]);
                regions.put((String) r[0], new double[]{Theme.num(r[1]), Theme.num(r[2]), Theme.num(r[3])});
            }
        } catch (SQLException e) { Theme.error(this, e); }

        // Seasonal recommendation: preselect the current season
        int m = Calendar.getInstance().get(Calendar.MONTH) + 1;
        season.setSelectedItem(m >= 6 && m <= 10 ? "Kharif" : (m == 4 || m == 5 ? "Summer" : "Rabi"));

        JPanel form = new JPanel(new GridLayout(0, 6, 8, 8));
        form.setOpaque(false);
        form.add(new JLabel("District")); form.add(district);
        form.add(new JLabel("Temperature °C")); form.add(temp);
        form.add(new JLabel("Humidity %")); form.add(hum);
        form.add(new JLabel("Soil pH")); form.add(ph);
        form.add(new JLabel("Soil type")); form.add(soil);
        form.add(new JLabel("Sunlight")); form.add(sunlight);
        form.add(new JLabel("Season")); form.add(season);
        form.add(new JLabel("Water available")); form.add(water);
        form.add(Theme.button("Auto-fill temperature", e -> autoFill()));
        form.add(Theme.button("Find best seeds", e -> find()));

        JPanel top = new JPanel(new BorderLayout(0, 8));
        top.setOpaque(false);
        top.add(Theme.title("Find the Best Seed"), BorderLayout.NORTH);
        top.add(form, BorderLayout.CENTER);
        top.add(info, BorderLayout.SOUTH);

        Theme.style(table);
        table.getSelectionModel().addListSelectionListener(e -> { if (!e.getValueIsAdjusting()) showNotes(); });

        notes.setEditable(false); notes.setLineWrap(true); notes.setWrapStyleWord(true);
        JScrollPane notesPane = new JScrollPane(notes);
        notesPane.setBorder(BorderFactory.createTitledBorder("Companion planting & crop rotation"));
        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        buttons.setOpaque(false);
        buttons.add(Theme.button("Request selected", e -> request()));
        buttons.add(Theme.button("Compare 2 seeds", e -> compare()));
        buttons.add(Theme.button("Planting calendar", e -> calendar()));
        buttons.add(Theme.button("My search history", e -> history()));
        JPanel bottom = new JPanel(new BorderLayout(0, 8));
        bottom.setOpaque(false);
        bottom.add(notesPane, BorderLayout.CENTER);
        bottom.add(buttons, BorderLayout.SOUTH);

        add(top, BorderLayout.NORTH);
        add(new JScrollPane(table), BorderLayout.CENTER);
        add(bottom, BorderLayout.SOUTH);
    }

    private static double val(JSpinner s) { return ((Number) s.getValue()).doubleValue(); }

    // Fully offline: fills in the district's average temperature from the built-in table
    private void autoFill() {
        double[] r = regions.get((String) district.getSelectedItem());
        if (r == null) return;
        temp.setValue(r[2]);
        info.setText("Average temperature for " + district.getSelectedItem() + " filled in (" + r[2] + " C). Adjust humidity and the rest if needed.");
    }

    private void find() {
        try {
            String d = (String) district.getSelectedItem();
            results = RecommendationService.recommend(SeedDAO.getAvailable(), val(temp), val(hum), val(ph),
                    (String) soil.getSelectedItem(), (String) sunlight.getSelectedItem(), (String) season.getSelectedItem(),
                    (String) water.getSelectedItem(), d, SeedDAO.feedback(d));
            model.setRowCount(0);
            for (Seed s : results)
                model.addRow(new Object[]{(s.rare ? "★ " : "") + s.name, s.batchId, s.score + "%", s.viability(), s.stockKg, s.daysToHarvest, s.reason});
            if (results.isEmpty()) { Theme.msg(this, "No suitable seeds in stock for these conditions."); return; }
            Db.exec("INSERT INTO search_history (search_id, client_id, temperature, humidity, ph, soil, sunlight, season, water, top_seed) "
                  + "VALUES (seq_id.NEXTVAL, ?, ?, ?, ?, ?, ?, ?, ?, ?)", Me.id, val(temp), val(hum), val(ph),
                    soil.getSelectedItem(), sunlight.getSelectedItem(), season.getSelectedItem(), water.getSelectedItem(), results.get(0).name);
        } catch (SQLException e) { Theme.error(this, e); }
    }

    private Seed sel() {
        int r = table.getSelectedRow();
        return r < 0 ? null : results.get(table.convertRowIndexToModel(r));
    }

    private void showNotes() {
        Seed s = sel();
        if (s == null) { notes.setText(""); return; }
        try {
            StringBuilder sb = new StringBuilder();
            for (Object[] r : Db.query("SELECT c.seed_id, c.relation, c.note, a.name, o.name FROM companion c "
                    + "JOIN seed_variety a ON a.seed_id = c.seed_id JOIN seed_variety o ON o.seed_id = c.other_seed_id "
                    + "WHERE c.seed_id = ? OR c.other_seed_id = ?", s.seedId, s.seedId)) {
                boolean first = (int) Theme.num(r[0]) == s.seedId;
                String rel = (String) r[1], other = (String) (first ? r[4] : r[3]);
                if (rel.equals("COMPANION")) sb.append("Grows well with ").append(other);
                else if (rel.equals("AVOID")) sb.append("Avoid planting near ").append(other);
                else sb.append(first ? "Good to plant after " : "Can be followed by ").append(other);
                sb.append(" - ").append(r[2]).append("\n");
            }
            notes.setText(sb.length() == 0 ? "No companion or rotation notes for this seed yet." : sb.toString());
        } catch (SQLException e) { notes.setText(e.getMessage()); }
    }

    private void request() {
        Seed s = sel();
        if (s == null) { Theme.msg(this, "Select a seed first."); return; }
        String in = JOptionPane.showInputDialog(this, "Quantity of " + s.name + " in kg (available: " + s.stockKg + ")");
        if (in == null) return;
        try {
            double q = Double.parseDouble(in.trim());
            if (q <= 0 || q > s.stockKg) { Theme.msg(this, "Enter a quantity between 0 and " + s.stockKg + " kg."); return; }
            if (s.rare && q > s.maxRequestKg) { Theme.msg(this, "Rare variety: maximum " + s.maxRequestKg + " kg per request."); return; }
            Db.exec("INSERT INTO seed_request (request_id, client_id, batch_id, qty_kg) VALUES (seq_id.NEXTVAL, ?, ?, ?)", Me.id, s.batchId, q);
            Theme.msg(this, "Request sent. Status: PENDING staff approval.");
        } catch (NumberFormatException e) { Theme.msg(this, "Please enter a valid number.");
        } catch (SQLException e) { Theme.error(this, e); }
    }

    private void compare() {
        int[] rows = table.getSelectedRows();
        if (rows.length != 2) { Theme.msg(this, "Select exactly two seeds (Ctrl+click)."); return; }
        Seed a = results.get(table.convertRowIndexToModel(rows[0])), b = results.get(table.convertRowIndexToModel(rows[1]));
        String[][] d = {
            {"Match", a.score + "%", b.score + "%"},
            {"Temperature °C", a.minTemp + " - " + a.maxTemp, b.minTemp + " - " + b.maxTemp},
            {"Humidity %", a.minHum + " - " + a.maxHum, b.minHum + " - " + b.maxHum},
            {"Soil pH", a.minPh + " - " + a.maxPh, b.minPh + " - " + b.maxPh},
            {"Soil", a.soil, b.soil}, {"Sunlight", a.sunlight, b.sunlight}, {"Season", a.season, b.season},
            {"Water need", a.water, b.water}, {"Days to harvest", "" + a.daysToHarvest, "" + b.daysToHarvest},
            {"Germination", a.germination + "%", b.germination + "%"}, {"Stock (kg)", "" + a.stockKg, "" + b.stockKg}};
        JTable t = new JTable(d, new String[]{"", a.name, b.name});
        Theme.style(t);
        JScrollPane sp = new JScrollPane(t);
        sp.setPreferredSize(new Dimension(520, 310));
        JOptionPane.showMessageDialog(this, sp, "Compare seeds", JOptionPane.PLAIN_MESSAGE);
    }

    // Sowing / mid-season / harvest dates, exportable as an .ics file with reminders
    private void calendar() {
        Seed s = sel();
        if (s == null) { Theme.msg(this, "Select a seed first."); return; }
        String in = JOptionPane.showInputDialog(this, "Sowing date (yyyy-mm-dd):", LocalDate.now().toString());
        if (in == null) return;
        try {
            LocalDate sow = LocalDate.parse(in.trim()), mid = sow.plusDays(s.daysToHarvest / 2), harvest = sow.plusDays(s.daysToHarvest);
            int c = JOptionPane.showConfirmDialog(this, s.name + "\nSow: " + sow + "\nMid-season check: " + mid + "\nHarvest: " + harvest
                    + "\n\nSave as a calendar file (.ics) with reminders?", "Planting calendar", JOptionPane.YES_NO_OPTION);
            if (c != JOptionPane.YES_OPTION) return;
            String ics = "BEGIN:VCALENDAR\r\nVERSION:2.0\r\nPRODID:-//GreenVault//EN\r\n"
                    + event(s.name + " - sowing", sow) + event(s.name + " - mid-season check", mid) + event(s.name + " - harvest", harvest)
                    + "END:VCALENDAR\r\n";
            Exporter.saveText(this, "planting-calendar.ics", ics);
        } catch (Exception e) { Theme.msg(this, "Please use the format yyyy-mm-dd."); }
    }

    private static String event(String title, LocalDate d) {
        String stamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd'T'HHmmss"));
        return "BEGIN:VEVENT\r\nUID:" + UUID.randomUUID() + "\r\nDTSTAMP:" + stamp + "\r\nDTSTART;VALUE=DATE:" + d.toString().replace("-", "")
             + "\r\nSUMMARY:" + title + "\r\nBEGIN:VALARM\r\nTRIGGER:-P1D\r\nACTION:DISPLAY\r\nDESCRIPTION:" + title + "\r\nEND:VALARM\r\nEND:VEVENT\r\n";
    }

    private void history() {
        try {
            DefaultTableModel hm = Theme.model("When", "Temp", "Humidity", "pH", "Soil", "Sunlight", "Season", "Water", "Top seed");
            Theme.fill(hm, Db.query("SELECT * FROM (SELECT TO_CHAR(searched_on,'DD-MM HH24:MI'), temperature, humidity, ph, soil, sunlight, season, water, top_seed "
                    + "FROM search_history WHERE client_id = ? ORDER BY searched_on DESC) WHERE ROWNUM <= 15", Me.id));
            JTable t = new JTable(hm);
            Theme.style(t);
            JScrollPane sp = new JScrollPane(t);
            sp.setPreferredSize(new Dimension(680, 300));
            JOptionPane.showMessageDialog(this, sp, "My recent searches", JOptionPane.PLAIN_MESSAGE);
        } catch (SQLException e) { Theme.error(this, e); }
    }
}
