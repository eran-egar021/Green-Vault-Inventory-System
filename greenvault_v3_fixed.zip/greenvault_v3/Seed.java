public class Seed {
    public int seedId, batchId, germination, daysToExpiry, daysToHarvest;
    public String name, soil, sunlight, season, water;
    public double minTemp, maxTemp, minHum, maxHum, minPh, maxPh, stockKg, maxRequestKg;
    public boolean rare;
    public int score;       // set by RecommendationService
    public String reason;

    public String viability() {
        if (daysToExpiry <= 30) return "Expiring soon";
        if (germination >= 85) return "Excellent";
        if (germination >= 70) return "Good";
        return "Fair";
    }
}
