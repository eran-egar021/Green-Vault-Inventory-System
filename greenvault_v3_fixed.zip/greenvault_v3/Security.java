import java.security.MessageDigest;

public class Security {
    // Salted (username:password) SHA-256. BCrypt would be the production-grade choice.
    public static String hash(String username, String password) {
        try {
            byte[] d = MessageDigest.getInstance("SHA-256").digest((username + ":" + password).getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (byte b : d) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) { throw new RuntimeException(e); }
    }
}
