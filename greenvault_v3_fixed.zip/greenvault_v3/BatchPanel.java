import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;

public class BatchPanel extends JPanel {
    private final DefaultTableModel model = Theme.model("Batch", "Variety", "Stock (kg)", "Collected", "Expiry",
            "Germ %", "Predicted 90d %", "Origin", "Parent batch", "Storage");
    private final JTable table = new JTable(model);

    public BatchPanel() {
        setLayout(new BorderLayout(0, 10)); setOpaque(false);
        add(Theme.title("Seed Batches"), BorderLayout.NORTH);
        Theme.style(table);
        add(new JScrollPane(table), BorderLayout.CENTER);
        JPanel bar = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        bar.setOpaque(false);
        bar.add(Theme.button("Add batch", e -> add()));
        bar.add(Theme.button("Germination test", e -> test()));
        bar.add(Theme.button("QR code", e -> qr()));
        bar.add(Theme.button("Auto-assign storage", e -> assign()));
        bar.add(Theme.button("Export Excel", e -> Exporter.csv(this, table)));
        bar.add(Theme.button("Print / PDF", e -> Exporter.print(this, table)));
        add(bar, BorderLayout.SOUTH);
        load();
    }

    private void load() {
        try {
            model.setRowCount(0);
            for (Object[] r : Db.query("SELECT b.batch_id, v.name, b.quantity_kg, TO_CHAR(b.collected_date,'DD-MM-YYYY'), "
                    + "TO_CHAR(b.expiry_date,'DD-MM-YYYY'), b.germination_rate, b.origin, b.parent_batch_id, u.name, v.seed_id, "
                    + "TRUNC(SYSDATE - b.collected_date) FROM seed_batch b JOIN seed_variety v ON v.seed_id = b.seed_id "
                    + "LEFT JOIN storage_unit u ON u.unit_id = b.unit_id ORDER BY b.batch_id")) {
                long p = Math.round(ViabilityService.predict((int) Theme.num(r[0]), Theme.num(r[5]), Theme.num(r[10]), 90));
                model.addRow(new Object[]{r[0], r[1], r[2], r[3], r[4], r[5], p, r[6], r[7], r[8]});
            }
        } catch (SQLException e) { Theme.error(this, e); }
    }

    private int selectedRow() {
        int r = table.getSelectedRow();
        if (r < 0) { Theme.msg(this, "Select a batch first."); return -1; }
        return table.convertRowIndexToModel(r);
    }

    private void add() {
        try {
            JComboBox<String> variety = new JComboBox<>();
            for (Object[] r : Db.query("SELECT seed_id, name FROM seed_variety ORDER BY name")) variety.addItem(r[0] + " - " + r[1]);
            JTextField qty = new JTextField("100"), life = new JTextField("365"), germ = new JTextField("90"),
                       origin = new JTextField(), parent = new JTextField();
            Object[] form = {"Variety", variety, "Quantity (kg)", qty, "Shelf life (days)", life, "Germination %", germ,
                             "Origin (farmer / region)", origin, "Parent batch ID (optional)", parent};
            if (JOptionPane.showConfirmDialog(this, form, "New batch", JOptionPane.OK_CANCEL_OPTION) != JOptionPane.OK_OPTION) return;
            int seedId = Integer.parseInt(((String) variety.getSelectedItem()).split(" - ")[0]);
            int id = (int) Theme.num(Db.query("SELECT seq_id.NEXTVAL FROM dual").get(0)[0]);
            Object par = parent.getText().trim().isEmpty() ? null : (Object) Integer.valueOf(parent.getText().trim());
            Db.exec("INSERT INTO seed_batch (batch_id, seed_id, quantity_kg, collected_date, expiry_date, germination_rate, origin, parent_batch_id, unit_id) "
                  + "VALUES (?, ?, ?, SYSDATE, SYSDATE + ?, ?, ?, ?, ?)", id, seedId, Double.parseDouble(qty.getText().trim()),
                    Integer.parseInt(life.getText().trim()), Integer.parseInt(germ.getText().trim()), origin.getText().trim(), par, StoragePanel.bestUnit(seedId));
            load();
        } catch (NumberFormatException e) { Theme.msg(this, "Please enter valid numbers.");
        } catch (SQLException e) { Theme.error(this, e); }
    }

    private void test() {
        int r = selectedRow();
        if (r < 0) return;
        Object id = model.getValueAt(r, 0);
        String in = JOptionPane.showInputDialog(this, "Germination test result for batch " + id + " (%)");
        if (in == null) return;
        try {
            int rate = Integer.parseInt(in.trim());
            if (rate < 0 || rate > 100) throw new NumberFormatException();
            Db.exec("INSERT INTO germination_test (test_id, batch_id, rate) VALUES (seq_id.NEXTVAL, ?, ?)", id, rate);
            load();
        } catch (NumberFormatException e) { Theme.msg(this, "Enter a whole number between 0 and 100.");
        } catch (SQLException e) { Theme.error(this, e); }
    }

    // QR code carrying the batch's traceability details (generated offline, no library)
    private void qr() {
        int r = selectedRow();
        if (r < 0) return;
        Object parent = model.getValueAt(r, 8);
        String text = "GreenVault Batch #" + model.getValueAt(r, 0) + "\nVariety: " + model.getValueAt(r, 1)
                + "\nOrigin: " + model.getValueAt(r, 7) + "\nParent batch: " + (parent == null ? "-" : parent)
                + "\nCollected: " + model.getValueAt(r, 3) + "\nExpiry: " + model.getValueAt(r, 4)
                + "\nGermination: " + model.getValueAt(r, 5) + "%\nStorage: " + model.getValueAt(r, 9);
        QRService.show(this, "QR - Batch " + model.getValueAt(r, 0), text);
    }

    private void assign() {
        int r = selectedRow();
        if (r < 0) return;
        try {
            Object id = model.getValueAt(r, 0);
            int seedId = (int) Theme.num(Db.query("SELECT seed_id FROM seed_batch WHERE batch_id = ?", id).get(0)[0]);
            Db.exec("UPDATE seed_batch SET unit_id = ? WHERE batch_id = ?", StoragePanel.bestUnit(seedId), id);
            load();
        } catch (SQLException e) { Theme.error(this, e); }
    }
}
