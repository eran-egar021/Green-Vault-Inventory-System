import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.sql.SQLException;
import java.util.*;
import java.util.List;

public class StoragePanel extends JPanel {
    private final DefaultTableModel model = Theme.model("Unit", "Set temp °C", "Set humidity %", "Latest temp", "Latest humidity", "Status", "Batches stored");
    private final JTable table = new JTable(model);

    // Smart storage assignment: the unit whose settings are closest to the seed's ideal conditions
    public static Object bestUnit(int seedId) throws SQLException {
        List<Object[]> r = Db.query("SELECT unit_id FROM (SELECT u.unit_id FROM storage_unit u, seed_variety v WHERE v.seed_id = ? "
                + "ORDER BY ABS(u.set_temp - v.ideal_temp) + ABS(u.set_humidity - v.ideal_humidity)) WHERE ROWNUM = 1", seedId);
        return r.isEmpty() ? null : r.get(0)[0];
    }

    public StoragePanel() {
        setLayout(new BorderLayout(0, 10)); setOpaque(false);
        add(Theme.title("Storage Monitoring"), BorderLayout.NORTH);
        Theme.style(table);
        table.getColumnModel().getColumn(5).setCellRenderer(new DefaultTableCellRenderer() {
            @Override public Component getTableCellRendererComponent(JTable t, Object v, boolean sel, boolean foc, int r, int c) {
                Component x = super.getTableCellRendererComponent(t, v, sel, foc, r, c);
                if (!sel) x.setForeground("OUT OF RANGE".equals(v) ? Theme.WARN : Theme.MID);
                return x;
            }
        });
        add(new JScrollPane(table), BorderLayout.CENTER);
        JPanel bar = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        bar.setOpaque(false);
        bar.add(Theme.button("Take sensor readings (simulated)", e -> simulate()));
        bar.add(Theme.button("Re-assign all batches", e -> reassign()));
        add(bar, BorderLayout.SOUTH);
        load();
    }

    private void load() {
        try {
            model.setRowCount(0);
            for (Object[] u : Db.query("SELECT unit_id, name, set_temp, set_humidity FROM storage_unit ORDER BY unit_id")) {
                List<Object[]> rd = Db.query("SELECT temperature, humidity FROM (SELECT temperature, humidity FROM storage_reading "
                        + "WHERE unit_id = ? ORDER BY read_on DESC, reading_id DESC) WHERE ROWNUM = 1", u[0]);
                Object t = "-", h = "-", status = "No reading";
                if (!rd.isEmpty()) {
                    double tt = Theme.num(rd.get(0)[0]), hh = Theme.num(rd.get(0)[1]);
                    t = tt; h = hh;
                    status = (Math.abs(tt - Theme.num(u[2])) > 2 || Math.abs(hh - Theme.num(u[3])) > 5) ? "OUT OF RANGE" : "OK";
                }
                model.addRow(new Object[]{u[1], u[2], u[3], t, h, status, Db.one("SELECT COUNT(*) FROM seed_batch WHERE unit_id = ?", u[0])});
            }
        } catch (SQLException e) { Theme.error(this, e); }
    }

    // Stands in for real sensors: each reading drifts a little from the unit's set point
    private void simulate() {
        try {
            Random rnd = new Random();
            for (Object[] u : Db.query("SELECT unit_id, set_temp, set_humidity FROM storage_unit")) {
                double t = Math.round((Theme.num(u[1]) + rnd.nextDouble() * 5 - 2.5) * 10) / 10.0;
                double h = Math.round((Theme.num(u[2]) + rnd.nextDouble() * 12 - 6) * 10) / 10.0;
                Db.exec("INSERT INTO storage_reading (reading_id, unit_id, temperature, humidity) VALUES (seq_id.NEXTVAL, ?, ?, ?)", u[0], t, h);
            }
            load();
        } catch (SQLException e) { Theme.error(this, e); }
    }

    private void reassign() {
        try {
            for (Object[] b : Db.query("SELECT batch_id, seed_id FROM seed_batch"))
                Db.exec("UPDATE seed_batch SET unit_id = ? WHERE batch_id = ?", bestUnit((int) Theme.num(b[1])), b[0]);
            load();
            Theme.msg(this, "Every batch is now in its best-matching storage unit.");
        } catch (SQLException e) { Theme.error(this, e); }
    }
}
