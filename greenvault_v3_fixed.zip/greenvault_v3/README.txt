GreenVault v3 - setup
1. Run schema.sql in Oracle (fresh user, or drop the old tables first).
2. Edit greenvault.properties (or the defaults in Db.java) with your Oracle user and password.
3. Add only the ojdbc (Oracle JDBC) jar to the Eclipse build path. No other jars are needed.
4. Run WelcomeFrame.java.
Logins: admin/admin123, staff/staff123, client/client123 (or register a new client).
Java 11 or newer is required.

Changes in v3
- Removed the AI assistant (AssistantPanel.java and AssistantService.java deleted, "Ask GreenVault" tile gone).
- New earthy beige / brown / green theme (Theme.java).
- No mail or zxing jars. No emails are sent.
- QR codes are generated offline by QRService.java in plain Java (Save as PNG supported).
- Live weather removed: Find Seed now fills in the district average temperature. The whole project is offline.
- New card-grid home with big icon tiles (HomePanel.java, MainFrame.java).

Running the jar
- Put GreenVault.jar and your Oracle JDBC jar (ojdbc8.jar or ojdbc11.jar) in the same folder.
- Run:  java -jar GreenVault.jar
- Edit greenvault.properties (url, user, password) in that same folder. No rebuild needed.
- Oracle must be running and schema.sql must already be loaded.

Changes in v3.1 (review fixes)
- schema.sql now has 290 seed varieties (ids 1-290), from common (Ponni, Maize, Tomato) to very rare heritage seeds.
  Every variety has a starting batch, so the low-stock alerts only show the few demo cases.
- drop_all.sql added: run it first if you reload schema.sql into the same Oracle user.
- ViabilityService: age floor of 90 days, so fresh batches no longer get a wrong "collapsing" prediction.
- DashboardPanel and ForecastPanel: charts show the top 8 / top 10 varieties (290 bars were unreadable).
Load order in SQL*Plus:  @drop_all.sql   then   @schema.sql
