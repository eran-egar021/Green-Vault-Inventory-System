import java.sql.*;
import java.util.*;

public class Db {
    // Defaults. You can also override them without rebuilding: put a file named greenvault.properties
    // next to the jar (or project folder) with lines  url=...  user=...  password=...
    private static final Properties CFG = load();
    private static final String URL  = CFG.getProperty("url", "jdbc:oracle:thin:@localhost:1521:XE");
    private static final String USER = CFG.getProperty("user", "system");              // change to your Oracle user
    private static final String PASS = CFG.getProperty("password", "your_password");   // change to your password

    private static Properties load() {
        Properties p = new Properties();
        try (java.io.FileInputStream in = new java.io.FileInputStream("greenvault.properties")) { p.load(in); }
        catch (java.io.IOException ignored) { }
        return p;
    }

    public static Connection get() throws SQLException { return DriverManager.getConnection(URL, USER, PASS); }

    private static void bind(PreparedStatement ps, Object[] p) throws SQLException {
        for (int i = 0; i < p.length; i++) {
            if (p[i] == null) ps.setNull(i + 1, Types.NULL); else ps.setObject(i + 1, p[i]);
        }
    }

    // Runs a SELECT and returns every row as an Object[]
    public static List<Object[]> query(String sql, Object... p) throws SQLException {
        try (Connection c = get(); PreparedStatement ps = c.prepareStatement(sql)) {
            bind(ps, p);
            try (ResultSet rs = ps.executeQuery()) {
                int n = rs.getMetaData().getColumnCount();
                List<Object[]> out = new ArrayList<>();
                while (rs.next()) {
                    Object[] row = new Object[n];
                    for (int i = 0; i < n; i++) {
                        Object o = rs.getObject(i + 1);
                        row[i] = (o instanceof java.util.Date) ? new java.text.SimpleDateFormat("dd-MM-yyyy").format(o) : o;
                    }
                    out.add(row);
                }
                return out;
            }
        }
    }

    // INSERT / UPDATE / DELETE
    public static int exec(String sql, Object... p) throws SQLException {
        try (Connection c = get(); PreparedStatement ps = c.prepareStatement(sql)) { bind(ps, p); return ps.executeUpdate(); }
    }

    // Calls a stored procedure, e.g. "{call sp_decide_request(?,?)}"
    public static void call(String sql, Object... p) throws SQLException {
        try (Connection c = get(); CallableStatement cs = c.prepareCall(sql)) {
            for (int i = 0; i < p.length; i++) cs.setObject(i + 1, p[i]);
            cs.execute();
        }
    }

    public static String one(String sql, Object... p) throws SQLException {
        List<Object[]> r = query(sql, p);
        return r.isEmpty() || r.get(0)[0] == null ? "0" : r.get(0)[0].toString();
    }
}
