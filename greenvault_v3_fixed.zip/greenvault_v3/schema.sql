-- GreenVault v3 schema with 290 seed varieties (common to very rare).
-- Run on a fresh Oracle user, or run drop_all.sql first. Load with:  @schema.sql
SET DEFINE OFF
CREATE SEQUENCE seq_id START WITH 1000;

CREATE TABLE app_user (
  user_id NUMBER PRIMARY KEY, username VARCHAR2(30) UNIQUE NOT NULL,
  password_hash VARCHAR2(64) NOT NULL, full_name VARCHAR2(60), email VARCHAR2(80),
  role VARCHAR2(10) CHECK (role IN ('ADMIN','STAFF','CLIENT')), created_on DATE DEFAULT SYSDATE);

CREATE TABLE region (
  region_id NUMBER PRIMARY KEY, district VARCHAR2(40) UNIQUE, latitude NUMBER, longitude NUMBER, avg_temp NUMBER);

CREATE TABLE storage_unit (
  unit_id NUMBER PRIMARY KEY, name VARCHAR2(40), set_temp NUMBER, set_humidity NUMBER);

CREATE TABLE storage_reading (
  reading_id NUMBER PRIMARY KEY, unit_id NUMBER REFERENCES storage_unit(unit_id),
  temperature NUMBER(4,1), humidity NUMBER(4,1), read_on DATE DEFAULT SYSDATE);

CREATE TABLE seed_variety (
  seed_id NUMBER PRIMARY KEY, name VARCHAR2(60) NOT NULL,
  min_temp NUMBER, max_temp NUMBER, min_hum NUMBER, max_hum NUMBER,
  min_ph NUMBER(3,1), max_ph NUMBER(3,1),
  soil_type VARCHAR2(20), sunlight VARCHAR2(20), season VARCHAR2(20), water_need VARCHAR2(10),
  days_to_harvest NUMBER,
  is_rare CHAR(1) DEFAULT 'N', max_request_kg NUMBER DEFAULT 1000, reorder_level NUMBER DEFAULT 100,
  ideal_temp NUMBER, ideal_humidity NUMBER);

CREATE TABLE seed_batch (
  batch_id NUMBER PRIMARY KEY, seed_id NUMBER REFERENCES seed_variety(seed_id),
  quantity_kg NUMBER NOT NULL CHECK (quantity_kg >= 0),
  collected_date DATE, expiry_date DATE, germination_rate NUMBER(3),
  origin VARCHAR2(80), parent_batch_id NUMBER REFERENCES seed_batch(batch_id),
  unit_id NUMBER REFERENCES storage_unit(unit_id));

CREATE TABLE germination_test (
  test_id NUMBER PRIMARY KEY, batch_id NUMBER REFERENCES seed_batch(batch_id),
  test_date DATE DEFAULT SYSDATE, rate NUMBER(3));

CREATE TABLE seed_request (
  request_id NUMBER PRIMARY KEY, client_id NUMBER REFERENCES app_user(user_id),
  batch_id NUMBER REFERENCES seed_batch(batch_id), qty_kg NUMBER NOT NULL,
  status VARCHAR2(10) DEFAULT 'PENDING' CHECK (status IN ('PENDING','APPROVED','REJECTED')),
  request_date DATE DEFAULT SYSDATE);

CREATE TABLE feedback (
  feedback_id NUMBER PRIMARY KEY, request_id NUMBER REFERENCES seed_request(request_id),
  client_id NUMBER, seed_id NUMBER REFERENCES seed_variety(seed_id), district VARCHAR2(40),
  rating NUMBER(1) CHECK (rating BETWEEN 1 AND 5), remarks VARCHAR2(200), created_on DATE DEFAULT SYSDATE);

CREATE TABLE companion (
  seed_id NUMBER REFERENCES seed_variety(seed_id), other_seed_id NUMBER REFERENCES seed_variety(seed_id),
  relation VARCHAR2(10) CHECK (relation IN ('COMPANION','AVOID','FOLLOWS')), note VARCHAR2(120));

CREATE TABLE search_history (
  search_id NUMBER PRIMARY KEY, client_id NUMBER, searched_on DATE DEFAULT SYSDATE,
  temperature NUMBER, humidity NUMBER, ph NUMBER, soil VARCHAR2(20), sunlight VARCHAR2(20),
  season VARCHAR2(20), water VARCHAR2(10), top_seed VARCHAR2(60));

CREATE TABLE audit_log (
  log_id NUMBER PRIMARY KEY, table_name VARCHAR2(30), action VARCHAR2(10),
  changed_by VARCHAR2(30), changed_on DATE DEFAULT SYSDATE, details VARCHAR2(200));

-- VIEW: stock per variety (used by dashboard, alerts and forecast)
CREATE OR REPLACE VIEW v_stock AS
SELECT v.seed_id, v.name, v.reorder_level, NVL(SUM(b.quantity_kg),0) AS total_kg
FROM seed_variety v LEFT JOIN seed_batch b ON b.seed_id = v.seed_id
GROUP BY v.seed_id, v.name, v.reorder_level;

-- TRIGGER 1: audit every batch change
CREATE OR REPLACE TRIGGER trg_batch_audit
AFTER INSERT OR UPDATE OR DELETE ON seed_batch
FOR EACH ROW
DECLARE v_action VARCHAR2(10); v_details VARCHAR2(200);
BEGIN
  IF INSERTING THEN v_action := 'INSERT'; v_details := 'Batch ' || :NEW.batch_id || ' added, ' || :NEW.quantity_kg || ' kg';
  ELSIF UPDATING THEN v_action := 'UPDATE'; v_details := 'Batch ' || :OLD.batch_id || ' qty ' || :OLD.quantity_kg || ' -> ' || :NEW.quantity_kg || ', germ ' || :OLD.germination_rate || ' -> ' || :NEW.germination_rate;
  ELSE v_action := 'DELETE'; v_details := 'Batch ' || :OLD.batch_id || ' removed';
  END IF;
  INSERT INTO audit_log (log_id, table_name, action, changed_by, details)
  VALUES (seq_id.NEXTVAL, 'SEED_BATCH', v_action, USER, v_details);
END;
/

-- TRIGGER 2: approving a request deducts stock
CREATE OR REPLACE TRIGGER trg_request_approve
AFTER UPDATE OF status ON seed_request
FOR EACH ROW
WHEN (NEW.status = 'APPROVED' AND OLD.status = 'PENDING')
BEGIN
  UPDATE seed_batch SET quantity_kg = quantity_kg - :NEW.qty_kg WHERE batch_id = :NEW.batch_id;
  INSERT INTO audit_log (log_id, table_name, action, changed_by, details)
  VALUES (seq_id.NEXTVAL, 'SEED_REQUEST', 'APPROVE', USER, 'Request ' || :NEW.request_id || ' approved: ' || :NEW.qty_kg || ' kg');
END;
/

-- TRIGGER 3: a new germination test updates the batch's viability
CREATE OR REPLACE TRIGGER trg_test_update
AFTER INSERT ON germination_test
FOR EACH ROW
BEGIN
  UPDATE seed_batch SET germination_rate = :NEW.rate WHERE batch_id = :NEW.batch_id;
END;
/

-- STORED PROCEDURE: approve/reject with stock and rare-seed checks
CREATE OR REPLACE PROCEDURE sp_decide_request(p_req NUMBER, p_decision VARCHAR2) AS
  v_qty NUMBER; v_stock NUMBER; v_rare CHAR(1); v_max NUMBER;
BEGIN
  SELECT r.qty_kg, b.quantity_kg, v.is_rare, v.max_request_kg
    INTO v_qty, v_stock, v_rare, v_max
    FROM seed_request r JOIN seed_batch b ON b.batch_id = r.batch_id
    JOIN seed_variety v ON v.seed_id = b.seed_id
   WHERE r.request_id = p_req AND r.status = 'PENDING';
  IF p_decision = 'APPROVED' THEN
    IF v_qty > v_stock THEN RAISE_APPLICATION_ERROR(-20001, 'Not enough stock in this batch'); END IF;
    IF v_rare = 'Y' AND v_qty > v_max THEN RAISE_APPLICATION_ERROR(-20002, 'Rare variety limit exceeded: max ' || v_max || ' kg'); END IF;
  END IF;
  UPDATE seed_request SET status = p_decision WHERE request_id = p_req;
EXCEPTION WHEN NO_DATA_FOUND THEN
  RAISE_APPLICATION_ERROR(-20003, 'Request not found or already decided');
END;
/

-- SAMPLE DATA (values are approximate; verify against agriculture-department guidance)
-- Logins: admin/admin123, staff/staff123, client/client123 (salted SHA-256: username:password)
INSERT INTO app_user VALUES (1,'admin','bf6b5bdb74c79ece9fc0ad0ac9fb0359f9555d4f35a83b2e6ec69ae99e09603d','Admin User','',  'ADMIN',SYSDATE);
INSERT INTO app_user VALUES (2,'staff','d15127858f71b6c259d34c4779c097f17f59c81ff986f67cc88aa6bb3ad72a0f','Staff User','',  'STAFF',SYSDATE);
INSERT INTO app_user VALUES (3,'client','fcde34741f116aab1845645ade58d8ff234b05facc14b4c4ac289246c07396b9','Client User','','CLIENT',SYSDATE);

INSERT INTO region VALUES (1,'Sivakasi',9.4533,77.7924,32);
INSERT INTO region VALUES (2,'Madurai',9.9252,78.1198,33);
INSERT INTO region VALUES (3,'Coimbatore',11.0168,76.9558,28);
INSERT INTO region VALUES (4,'Chennai',13.0827,80.2707,31);
INSERT INTO region VALUES (5,'Thanjavur',10.7870,79.1378,31);
INSERT INTO region VALUES (6,'Thoothukudi',8.7642,78.1348,31);

INSERT INTO storage_unit VALUES (1,'Cold Room A',10,40);
INSERT INTO storage_unit VALUES (2,'Cool Store B',15,35);
INSERT INTO storage_unit VALUES (3,'Dry Store C',20,30);

-- id, name, minT, maxT, minHum, maxHum, minPh, maxPh, soil, sun, season, water, days, rare, maxReq, reorder, idealT, idealH
-- ids 1-9: original sample varieties.  ids 10-290: extended catalogue (tier: common, uncommon, rare, very rare).
-- Rare varieties have is_rare = 'Y', a small max_request_kg and a small stock; common ones sell up to 1000 kg.
INSERT INTO seed_variety VALUES (1,'Rice (Paddy)',20,35,60,90,5.5,7.0,'Clay','Full','Kharif','High',120,'N',1000,150,15,40);
INSERT INTO seed_variety VALUES (2,'Wheat',10,25,40,70,6.0,7.5,'Loamy','Full','Rabi','Medium',120,'N',1000,150,15,35);
INSERT INTO seed_variety VALUES (3,'Maize',18,32,50,80,5.8,7.0,'Loamy','Full','Kharif','Medium',90,'N',1000,100,15,35);
INSERT INTO seed_variety VALUES (4,'Groundnut',22,32,50,75,5.5,7.0,'Sandy','Full','Kharif','Low',110,'N',1000,80,10,40);
INSERT INTO seed_variety VALUES (5,'Tomato',18,30,50,75,6.0,7.0,'Loamy','Full','Summer','Medium',80,'N',1000,70,10,35);
INSERT INTO seed_variety VALUES (6,'Finger Millet (Ragi)',20,32,40,75,5.0,7.5,'Red','Full','Kharif','Low',100,'N',1000,100,20,30);
INSERT INTO seed_variety VALUES (7,'Cotton',21,35,50,80,6.0,8.0,'Black','Full','Kharif','Medium',160,'N',1000,80,15,35);
INSERT INTO seed_variety VALUES (8,'Spinach',10,24,50,80,6.0,7.0,'Loamy','Partial','Rabi','Medium',40,'N',1000,30,10,40);
INSERT INTO seed_variety VALUES (9,'Karuppu Kavuni Rice (Heritage)',22,34,60,90,5.5,7.0,'Clay','Full','Kharif','High',140,'Y',20,20,15,40);

INSERT INTO seed_variety VALUES (10,'Ponni Rice',20,35,65,90,5.5,6.8,'Clay','Full','Kharif','High',135,'N',1000,120,15,40);
INSERT INTO seed_variety VALUES (11,'ADT 43 Rice',19,33,60,90,5.3,7.0,'Clay','Full','Kharif','High',110,'N',1000,120,15,40);
INSERT INTO seed_variety VALUES (12,'ADT 45 Rice',20,34,65,90,5.5,6.8,'Clay','Full','Rabi','High',105,'N',1000,150,15,40);
INSERT INTO seed_variety VALUES (13,'CO 51 Rice',22,37,60,95,5.3,7.2,'Clay','Full','Kharif','High',110,'N',1000,150,15,40);
INSERT INTO seed_variety VALUES (14,'IR 20 Rice',19,37,65,90,5.7,7.0,'Clay','Full','Kharif','High',115,'N',1000,120,15,40);
INSERT INTO seed_variety VALUES (15,'IR 64 Rice',18,35,60,85,5.3,7.2,'Clay','Full','Kharif','High',120,'N',1000,100,15,40);
INSERT INTO seed_variety VALUES (16,'BPT 5204 Samba Mahsuri',20,36,60,85,5.3,7.0,'Clay','Full','Rabi','High',150,'N',1000,100,15,40);
INSERT INTO seed_variety VALUES (17,'TKM 9 Rice',21,34,65,90,5.3,7.0,'Clay','Full','Kharif','High',105,'N',1000,150,15,40);
INSERT INTO seed_variety VALUES (18,'Swarna Rice',22,34,55,90,5.5,7.0,'Clay','Full','Kharif','High',140,'N',1000,150,15,40);
INSERT INTO seed_variety VALUES (19,'MTU 1010 Rice',18,33,60,85,5.3,7.2,'Clay','Full','Kharif','High',115,'N',1000,150,15,40);
INSERT INTO seed_variety VALUES (20,'ASD 16 Rice',21,34,55,85,5.5,7.0,'Clay','Full','Kharif','High',110,'N',1000,100,15,40);
INSERT INTO seed_variety VALUES (21,'Jaya Rice',19,37,65,90,5.7,7.2,'Clay','Full','Kharif','High',130,'N',1000,150,15,40);
INSERT INTO seed_variety VALUES (22,'Sona Masuri Rice',20,35,55,85,5.5,7.0,'Clay','Full','Rabi','High',135,'N',500,60,15,40);
INSERT INTO seed_variety VALUES (23,'Pusa Basmati 1121',20,36,60,90,5.5,7.0,'Loamy','Full','Kharif','High',145,'N',500,70,15,40);
INSERT INTO seed_variety VALUES (24,'Kerala Matta Rosematta',20,36,55,85,5.5,6.8,'Clay','Full','Kharif','High',130,'N',500,50,15,40);
INSERT INTO seed_variety VALUES (25,'Red Rice Sivappu Arisi',18,35,65,90,5.5,6.8,'Clay','Full','Kharif','High',125,'N',500,40,15,40);
INSERT INTO seed_variety VALUES (26,'CO 43 Rice',18,35,60,85,5.5,7.2,'Clay','Full','Kharif','High',110,'N',500,50,15,40);
INSERT INTO seed_variety VALUES (27,'Mapillai Samba',20,33,55,90,5.7,7.0,'Clay','Full','Kharif','High',160,'Y',50,15,15,40);
INSERT INTO seed_variety VALUES (28,'Kullakar',20,35,60,95,5.5,7.0,'Clay','Full','Kharif','High',100,'Y',20,15,15,40);
INSERT INTO seed_variety VALUES (29,'Kichili Samba',18,35,60,90,5.5,7.0,'Clay','Full','Rabi','High',130,'Y',40,12,15,40);
INSERT INTO seed_variety VALUES (30,'Seeraga Samba',19,37,60,85,5.7,7.0,'Clay','Full','Rabi','High',140,'Y',20,12,15,40);
INSERT INTO seed_variety VALUES (31,'Salem Sannam',18,34,60,90,5.3,6.8,'Clay','Full','Rabi','High',135,'Y',30,12,15,40);
INSERT INTO seed_variety VALUES (32,'Kala Namak Rice',21,34,65,90,5.5,7.0,'Clay','Full','Kharif','High',150,'Y',40,10,15,40);
INSERT INTO seed_variety VALUES (33,'Thooyamalli',21,33,65,90,5.5,7.0,'Clay','Full','Kharif','High',135,'Y',5,5,15,40);
INSERT INTO seed_variety VALUES (34,'Poongar',18,33,60,90,5.5,7.0,'Clay','Full','Kharif','High',70,'Y',5,6,15,40);
INSERT INTO seed_variety VALUES (35,'Kudavazhai',22,33,60,90,5.3,7.0,'Clay','Full','Kharif','High',100,'Y',5,5,15,40);
INSERT INTO seed_variety VALUES (36,'Karunguruvai',21,33,60,90,5.3,7.0,'Clay','Full','Kharif','High',100,'Y',8,3,15,40);
INSERT INTO seed_variety VALUES (37,'Neelam Samba',21,35,55,90,5.5,6.8,'Clay','Full','Rabi','High',135,'Y',4,3,15,40);
INSERT INTO seed_variety VALUES (38,'Kattuyanam',21,37,55,90,5.7,7.0,'Clay','Full','Kharif','High',170,'Y',4,3,15,40);
INSERT INTO seed_variety VALUES (39,'Thanga Samba',22,33,60,90,5.3,7.2,'Clay','Full','Rabi','High',135,'Y',4,5,15,40);
INSERT INTO seed_variety VALUES (40,'Chithiraikar',22,35,65,95,5.5,7.0,'Clay','Full','Kharif','High',120,'Y',4,3,15,40);
INSERT INTO seed_variety VALUES (41,'Kappakar',20,35,60,90,5.5,7.0,'Clay','Full','Kharif','High',120,'Y',3,5,15,40);
INSERT INTO seed_variety VALUES (42,'Illupai Poo Samba',19,36,60,95,5.3,6.8,'Clay','Full','Rabi','High',130,'Y',3,4,15,40);
INSERT INTO seed_variety VALUES (43,'Vellai Kavuni',20,35,60,95,5.7,6.8,'Clay','Full','Kharif','High',135,'Y',5,5,15,40);
INSERT INTO seed_variety VALUES (44,'Norungan',18,33,55,95,5.5,7.0,'Clay','Full','Kharif','High',120,'Y',5,3,15,40);
INSERT INTO seed_variety VALUES (45,'Aathur Kichili Samba',20,34,60,90,5.7,7.2,'Clay','Full','Rabi','High',130,'Y',8,4,15,40);
INSERT INTO seed_variety VALUES (46,'Garudan Samba',21,35,65,90,5.3,6.8,'Clay','Full','Rabi','High',135,'Y',8,3,15,40);
INSERT INTO seed_variety VALUES (47,'Navara Rice',18,35,60,90,5.5,7.2,'Clay','Full','Kharif','High',70,'Y',8,3,15,40);
INSERT INTO seed_variety VALUES (48,'Njavara Rice',19,36,55,90,5.5,7.0,'Clay','Full','Kharif','High',75,'Y',4,4,15,40);
INSERT INTO seed_variety VALUES (49,'Pearl Millet Bajra',20,37,35,70,5.0,7.5,'Sandy','Full','Kharif','Low',85,'N',1000,100,20,30);
INSERT INTO seed_variety VALUES (50,'Sorghum Cholam',20,37,35,70,4.8,7.3,'Black','Full','Kharif','Low',110,'N',1000,150,20,30);
INSERT INTO seed_variety VALUES (51,'Foxtail Millet Thinai',21,35,30,70,5.2,7.7,'Red','Full','Kharif','Low',80,'N',1000,120,20,30);
INSERT INTO seed_variety VALUES (52,'Little Millet Samai',21,34,35,75,5.0,7.3,'Red','Full','Kharif','Low',75,'N',1000,150,20,30);
INSERT INTO seed_variety VALUES (53,'Kodo Millet Varagu',20,37,35,75,5.2,7.5,'Red','Full','Kharif','Low',100,'N',1000,100,20,30);
INSERT INTO seed_variety VALUES (54,'Barnyard Millet Kuthiraivali',18,37,40,65,5.2,7.3,'Loamy','Full','Kharif','Low',70,'N',1000,100,20,30);
INSERT INTO seed_variety VALUES (55,'Proso Millet Panivaragu',21,35,30,70,5.2,7.5,'Sandy','Full','Kharif','Low',70,'N',1000,150,20,30);
INSERT INTO seed_variety VALUES (56,'Ragi CO 15',20,33,40,75,5.2,7.7,'Red','Full','Kharif','Low',100,'N',1000,100,20,30);
INSERT INTO seed_variety VALUES (57,'Sorghum CO 30',22,33,35,75,5.2,7.7,'Black','Full','Rabi','Low',105,'N',1000,150,20,30);
INSERT INTO seed_variety VALUES (58,'Pearl Millet CO 10',19,34,30,75,4.8,7.5,'Sandy','Full','Summer','Low',80,'N',1000,150,20,30);
INSERT INTO seed_variety VALUES (59,'Browntop Millet',20,35,35,65,4.8,7.5,'Red','Full','Summer','Low',75,'N',500,60,20,30);
INSERT INTO seed_variety VALUES (60,'Sweet Sorghum',20,35,35,70,5.0,7.5,'Black','Full','Kharif','Medium',120,'N',500,70,20,30);
INSERT INTO seed_variety VALUES (61,'Foxtail Millet CO 7',20,35,40,70,5.2,7.5,'Red','Full','Kharif','Low',80,'N',500,50,20,30);
INSERT INTO seed_variety VALUES (62,'Little Millet CO 4',20,36,35,75,5.0,7.5,'Red','Full','Kharif','Low',75,'N',500,70,20,30);
INSERT INTO seed_variety VALUES (63,'Kodo Millet CO 3',22,37,30,70,4.8,7.7,'Red','Full','Kharif','Low',95,'N',500,70,20,30);
INSERT INTO seed_variety VALUES (64,'Teff',20,35,35,70,4.8,7.5,'Loamy','Full','Summer','Medium',110,'Y',50,12,20,30);
INSERT INTO seed_variety VALUES (65,'Quinoa',18,37,30,70,5.0,7.7,'Sandy','Full','Rabi','Low',110,'Y',50,12,20,30);
INSERT INTO seed_variety VALUES (66,'Buckwheat',18,33,30,65,5.0,7.7,'Loamy','Full','Rabi','Medium',90,'Y',20,10,20,30);
INSERT INTO seed_variety VALUES (67,'Amaranth Grain Rajgira',20,35,35,65,5.2,7.3,'Loamy','Full','Kharif','Low',110,'Y',50,12,20,30);
INSERT INTO seed_variety VALUES (68,'Jobs Tears',22,34,40,70,5.0,7.7,'Loamy','Full','Kharif','Medium',150,'Y',4,5,20,30);
INSERT INTO seed_variety VALUES (69,'Fonio',18,33,40,70,4.8,7.5,'Sandy','Full','Kharif','Low',85,'Y',4,3,20,30);
INSERT INTO seed_variety VALUES (70,'Wheat HD 2967',13,34,35,75,6.2,7.3,'Loamy','Full','Rabi','Medium',125,'N',1000,120,15,35);
INSERT INTO seed_variety VALUES (71,'Wheat PBW 343',17,34,40,75,5.8,7.3,'Loamy','Full','Rabi','Medium',130,'N',1000,100,15,35);
INSERT INTO seed_variety VALUES (72,'Maize Hybrid',14,32,40,70,6.0,7.3,'Loamy','Full','Kharif','Medium',95,'N',1000,150,15,35);
INSERT INTO seed_variety VALUES (73,'Sweet Corn',15,34,45,70,6.0,7.5,'Loamy','Full','Summer','Medium',80,'N',1000,120,15,35);
INSERT INTO seed_variety VALUES (74,'Barley',16,30,35,65,5.8,7.3,'Loamy','Full','Rabi','Low',120,'N',1000,120,15,35);
INSERT INTO seed_variety VALUES (75,'Oats',15,30,45,65,6.0,7.5,'Loamy','Full','Rabi','Medium',110,'N',1000,120,15,35);
INSERT INTO seed_variety VALUES (76,'Durum Wheat',15,31,40,65,6.0,7.5,'Black','Full','Rabi','Medium',120,'N',500,60,15,35);
INSERT INTO seed_variety VALUES (77,'Baby Corn',17,31,40,70,6.0,7.5,'Loamy','Full','Summer','Medium',60,'N',500,50,15,35);
INSERT INTO seed_variety VALUES (78,'Popcorn',15,30,45,75,6.0,7.5,'Loamy','Full','Kharif','Medium',100,'N',500,50,15,35);
INSERT INTO seed_variety VALUES (79,'Triticale',14,33,40,70,5.8,7.5,'Loamy','Full','Rabi','Medium',130,'N',500,60,15,35);
INSERT INTO seed_variety VALUES (80,'Khapli Emmer Wheat',17,33,40,70,5.8,7.5,'Black','Full','Rabi','Low',115,'Y',20,12,15,35);
INSERT INTO seed_variety VALUES (81,'Purple Maize',13,31,40,70,6.0,7.5,'Loamy','Full','Kharif','Medium',105,'Y',50,10,15,35);
INSERT INTO seed_variety VALUES (82,'Black Wheat',17,32,40,70,6.0,7.7,'Loamy','Full','Rabi','Medium',130,'Y',25,15,15,35);
INSERT INTO seed_variety VALUES (83,'Rye',15,31,40,70,6.2,7.3,'Sandy','Full','Rabi','Low',125,'Y',20,15,15,35);
INSERT INTO seed_variety VALUES (84,'Black Gram Urad',22,34,40,75,5.8,7.3,'Loamy','Full','Kharif','Low',70,'N',1000,100,15,35);
INSERT INTO seed_variety VALUES (85,'Green Gram Moong',18,34,40,70,6.2,7.5,'Loamy','Full','Summer','Low',65,'N',1000,150,15,35);
INSERT INTO seed_variety VALUES (86,'Red Gram Toor',18,32,45,75,6.0,7.3,'Red','Full','Kharif','Low',160,'N',1000,120,15,35);
INSERT INTO seed_variety VALUES (87,'Bengal Gram Chana',20,32,40,75,6.0,7.5,'Black','Full','Rabi','Low',100,'N',1000,120,15,35);
INSERT INTO seed_variety VALUES (88,'Lentil Masoor',19,33,45,70,6.0,7.3,'Loamy','Full','Rabi','Low',105,'N',1000,120,15,35);
INSERT INTO seed_variety VALUES (89,'Field Pea',19,31,40,70,6.0,7.3,'Loamy','Full','Rabi','Medium',90,'N',1000,120,15,35);
INSERT INTO seed_variety VALUES (90,'Cowpea',19,32,45,75,6.0,7.3,'Sandy','Full','Summer','Low',75,'N',1000,120,15,35);
INSERT INTO seed_variety VALUES (91,'Horse Gram Kollu',21,30,45,75,6.0,7.5,'Red','Full','Rabi','Low',90,'N',1000,120,15,35);
INSERT INTO seed_variety VALUES (92,'Lablab Bean Avarai',20,34,45,75,6.2,7.5,'Loamy','Full','Rabi','Medium',120,'N',1000,100,15,35);
INSERT INTO seed_variety VALUES (93,'Cluster Bean Guar',22,33,40,70,6.0,7.7,'Sandy','Full','Summer','Low',90,'N',1000,150,15,35);
INSERT INTO seed_variety VALUES (94,'Soybean',18,32,45,75,5.8,7.5,'Black','Full','Kharif','Medium',95,'N',1000,100,15,35);
INSERT INTO seed_variety VALUES (95,'Black Gram CO 6',20,31,40,75,5.8,7.3,'Loamy','Full','Kharif','Low',70,'N',1000,150,15,35);
INSERT INTO seed_variety VALUES (96,'Green Gram CO 8',20,30,50,70,6.2,7.5,'Loamy','Full','Summer','Low',60,'N',1000,100,15,35);
INSERT INTO seed_variety VALUES (97,'Red Gram CO 7',20,32,50,75,6.2,7.3,'Red','Full','Kharif','Low',150,'N',1000,100,15,35);
INSERT INTO seed_variety VALUES (98,'Moth Bean',19,30,45,80,6.2,7.7,'Sandy','Full','Kharif','Low',75,'N',500,40,15,35);
INSERT INTO seed_variety VALUES (99,'Kidney Bean Rajma',22,32,40,70,6.0,7.3,'Loamy','Full','Rabi','Medium',100,'N',500,40,15,35);
INSERT INTO seed_variety VALUES (100,'Chickpea Kabuli',19,32,50,80,6.0,7.3,'Black','Full','Rabi','Medium',105,'N',500,60,15,35);
INSERT INTO seed_variety VALUES (101,'Lima Bean',20,32,40,75,6.0,7.7,'Loamy','Full','Kharif','Medium',110,'N',500,50,15,35);
INSERT INTO seed_variety VALUES (102,'Black Eyed Pea',22,34,50,75,6.0,7.7,'Sandy','Full','Summer','Low',70,'N',500,40,15,35);
INSERT INTO seed_variety VALUES (103,'French Bean Bush',20,32,50,70,6.2,7.7,'Loamy','Full','Rabi','Medium',60,'N',500,70,15,35);
INSERT INTO seed_variety VALUES (104,'Rice Bean',21,34,40,70,6.0,7.3,'Loamy','Full','Kharif','Medium',110,'Y',30,10,15,35);
INSERT INTO seed_variety VALUES (105,'Adzuki Bean',21,33,50,75,6.2,7.7,'Loamy','Full','Kharif','Medium',100,'Y',50,15,15,35);
INSERT INTO seed_variety VALUES (106,'Winged Bean',20,34,40,75,6.0,7.5,'Loamy','Full','Kharif','High',140,'Y',30,10,15,35);
INSERT INTO seed_variety VALUES (107,'Velvet Bean Mucuna',20,31,45,70,6.0,7.5,'Red','Full','Kharif','Low',150,'Y',40,10,15,35);
INSERT INTO seed_variety VALUES (108,'Sword Bean',18,31,40,70,5.8,7.7,'Loamy','Full','Kharif','Medium',150,'Y',50,10,15,35);
INSERT INTO seed_variety VALUES (109,'Perennial Pigeon Pea',20,32,45,75,6.0,7.5,'Red','Full','Kharif','Low',240,'Y',40,12,15,35);
INSERT INTO seed_variety VALUES (110,'Sesame Gingelly',21,32,45,80,6.0,7.5,'Sandy','Full','Summer','Low',85,'N',1000,100,15,35);
INSERT INTO seed_variety VALUES (111,'Sunflower',19,33,50,70,5.8,7.3,'Black','Full','Rabi','Medium',90,'N',1000,120,15,35);
INSERT INTO seed_variety VALUES (112,'Castor',20,33,40,75,6.2,7.5,'Red','Full','Kharif','Low',150,'N',1000,120,15,35);
INSERT INTO seed_variety VALUES (113,'Safflower',20,34,45,75,6.2,7.7,'Black','Full','Rabi','Low',120,'N',1000,150,15,35);
INSERT INTO seed_variety VALUES (114,'Mustard',20,32,45,70,5.8,7.5,'Loamy','Full','Rabi','Low',110,'N',1000,120,15,35);
INSERT INTO seed_variety VALUES (115,'Groundnut TMV 7',21,34,40,75,5.8,7.5,'Sandy','Full','Kharif','Low',105,'N',1000,100,15,35);
INSERT INTO seed_variety VALUES (116,'Groundnut VRI 2',22,30,40,80,6.0,7.5,'Red','Full','Kharif','Low',105,'N',1000,150,15,35);
INSERT INTO seed_variety VALUES (117,'Rapeseed Canola',18,32,45,75,6.0,7.3,'Loamy','Full','Rabi','Medium',120,'N',1000,150,15,35);
INSERT INTO seed_variety VALUES (118,'White Sesame',21,32,40,75,6.2,7.3,'Sandy','Full','Summer','Low',80,'N',500,50,15,35);
INSERT INTO seed_variety VALUES (119,'Black Sesame',19,32,40,75,5.8,7.5,'Sandy','Full','Summer','Low',90,'N',500,50,15,35);
INSERT INTO seed_variety VALUES (120,'Linseed',19,33,40,75,6.0,7.5,'Loamy','Full','Rabi','Low',120,'N',500,40,15,35);
INSERT INTO seed_variety VALUES (121,'Niger',18,32,50,75,6.2,7.5,'Red','Full','Kharif','Low',100,'N',500,60,15,35);
INSERT INTO seed_variety VALUES (122,'Groundnut Bunch',20,34,45,80,5.8,7.5,'Sandy','Full','Kharif','Low',100,'N',500,60,15,35);
INSERT INTO seed_variety VALUES (123,'Groundnut Spanish',20,32,45,75,5.8,7.5,'Sandy','Full','Rabi','Low',105,'N',500,60,15,35);
INSERT INTO seed_variety VALUES (124,'Camelina',21,31,45,80,6.0,7.7,'Loamy','Full','Rabi','Low',100,'Y',20,15,15,35);
INSERT INTO seed_variety VALUES (125,'Chia',20,33,45,70,5.8,7.3,'Sandy','Full','Kharif','Low',115,'Y',30,15,15,35);
INSERT INTO seed_variety VALUES (126,'Perilla',21,31,45,80,6.0,7.7,'Loamy','Full','Kharif','Medium',120,'Y',50,10,15,35);
INSERT INTO seed_variety VALUES (127,'Tomato PKM 1',20,31,45,80,6.0,7.2,'Loamy','Full','Summer','Medium',75,'N',1000,100,10,35);
INSERT INTO seed_variety VALUES (128,'Tomato Cherry',18,34,55,75,5.8,7.0,'Loamy','Full','Summer','Medium',70,'N',1000,100,10,35);
INSERT INTO seed_variety VALUES (129,'Tomato Roma',17,32,50,80,6.0,7.2,'Loamy','Full','Rabi','Medium',80,'N',1000,150,10,35);
INSERT INTO seed_variety VALUES (130,'Brinjal Long Purple',17,33,55,85,6.0,7.0,'Loamy','Full','Summer','Medium',110,'N',1000,100,10,35);
INSERT INTO seed_variety VALUES (131,'Brinjal Round Green',18,33,45,80,6.0,6.8,'Loamy','Full','Kharif','Medium',110,'N',1000,120,10,35);
INSERT INTO seed_variety VALUES (132,'Chilli CO 1',20,32,50,80,6.2,7.0,'Red','Full','Kharif','Medium',150,'N',1000,150,10,35);
INSERT INTO seed_variety VALUES (133,'Chilli Guntur Sannam',19,32,50,80,6.0,7.2,'Red','Full','Kharif','Medium',150,'N',1000,150,10,35);
INSERT INTO seed_variety VALUES (134,'Bhendi Arka Anamika',18,32,55,85,6.0,7.2,'Loamy','Full','Summer','Medium',60,'N',1000,150,10,35);
INSERT INTO seed_variety VALUES (135,'Bhendi CO 3',18,31,50,80,6.2,7.0,'Loamy','Full','Kharif','Medium',60,'N',1000,150,10,35);
INSERT INTO seed_variety VALUES (136,'Ridge Gourd',20,32,50,85,6.2,7.0,'Loamy','Full','Summer','Medium',80,'N',1000,100,10,35);
INSERT INTO seed_variety VALUES (137,'Bitter Gourd',19,32,50,75,6.2,7.0,'Loamy','Full','Summer','Medium',80,'N',1000,100,10,35);
INSERT INTO seed_variety VALUES (138,'Snake Gourd',20,30,50,75,6.0,7.0,'Loamy','Full','Summer','Medium',90,'N',1000,100,10,35);
INSERT INTO seed_variety VALUES (139,'Bottle Gourd',20,32,50,85,6.0,7.2,'Loamy','Full','Summer','Medium',90,'N',1000,120,10,35);
INSERT INTO seed_variety VALUES (140,'Ash Gourd',18,34,50,85,6.0,7.2,'Loamy','Full','Kharif','Medium',120,'N',1000,100,10,35);
INSERT INTO seed_variety VALUES (141,'Pumpkin',18,32,55,75,6.0,7.2,'Loamy','Full','Kharif','Medium',110,'N',1000,100,10,35);
INSERT INTO seed_variety VALUES (142,'Cucumber',16,32,50,80,6.0,6.8,'Loamy','Full','Summer','Medium',55,'N',1000,150,10,35);
INSERT INTO seed_variety VALUES (143,'Radish',18,30,50,80,6.0,7.0,'Loamy','Full','Rabi','Medium',45,'N',1000,120,10,35);
INSERT INTO seed_variety VALUES (144,'Carrot',20,32,45,75,6.2,7.0,'Loamy','Full','Rabi','Medium',90,'N',1000,120,10,35);
INSERT INTO seed_variety VALUES (145,'Beetroot',16,32,50,80,6.2,6.8,'Loamy','Full','Rabi','Medium',65,'N',1000,150,10,35);
INSERT INTO seed_variety VALUES (146,'Onion',16,34,55,75,6.0,6.8,'Red','Full','Rabi','Medium',120,'N',1000,120,10,35);
INSERT INTO seed_variety VALUES (147,'Cabbage',17,34,55,85,5.8,7.0,'Loamy','Full','Rabi','High',90,'N',1000,120,10,35);
INSERT INTO seed_variety VALUES (148,'Cauliflower',18,31,50,75,6.0,7.2,'Loamy','Full','Rabi','High',90,'N',1000,150,10,35);
INSERT INTO seed_variety VALUES (149,'Drumstick PKM 1',20,31,50,80,6.2,6.8,'Red','Full','Kharif','Low',180,'N',1000,100,10,35);
INSERT INTO seed_variety VALUES (150,'Bitter Gourd CO 1',19,30,45,75,5.8,6.8,'Loamy','Full','Summer','Medium',75,'N',1000,100,10,35);
INSERT INTO seed_variety VALUES (151,'Chilli Byadgi',19,33,55,75,6.0,7.0,'Red','Full','Kharif','Medium',150,'N',500,40,10,35);
INSERT INTO seed_variety VALUES (152,'Brinjal Kathiri',18,32,45,80,6.0,7.0,'Loamy','Full','Summer','Medium',110,'N',500,50,10,35);
INSERT INTO seed_variety VALUES (153,'Okra Pusa A4',18,34,55,80,5.8,7.0,'Loamy','Full','Summer','Medium',60,'N',500,50,10,35);
INSERT INTO seed_variety VALUES (154,'Broccoli',18,32,50,80,6.0,7.0,'Loamy','Full','Rabi','High',85,'N',500,40,10,35);
INSERT INTO seed_variety VALUES (155,'Knol Khol Kohlrabi',16,32,55,85,6.0,7.0,'Loamy','Full','Rabi','Medium',60,'N',500,50,10,35);
INSERT INTO seed_variety VALUES (156,'Turnip',16,32,55,75,6.0,7.2,'Loamy','Full','Rabi','Medium',55,'N',500,70,10,35);
INSERT INTO seed_variety VALUES (157,'Muskmelon',19,34,55,80,5.8,6.8,'Sandy','Full','Summer','Medium',85,'N',500,60,10,35);
INSERT INTO seed_variety VALUES (158,'Watermelon',16,30,50,75,6.2,7.2,'Sandy','Full','Summer','Medium',85,'N',500,70,10,35);
INSERT INTO seed_variety VALUES (159,'Zucchini',16,32,50,85,5.8,6.8,'Loamy','Full','Summer','Medium',55,'N',500,70,10,35);
INSERT INTO seed_variety VALUES (160,'Sweet Pepper Capsicum',18,30,45,75,6.0,7.0,'Loamy','Full','Rabi','Medium',90,'N',500,60,10,35);
INSERT INTO seed_variety VALUES (161,'Cucumber Gherkin',20,31,55,80,6.0,6.8,'Loamy','Full','Summer','Medium',50,'N',500,70,10,35);
INSERT INTO seed_variety VALUES (162,'Spring Onion',18,31,50,80,6.0,7.0,'Loamy','Full','Rabi','Medium',60,'N',500,60,10,35);
INSERT INTO seed_variety VALUES (163,'Drumstick PKM 2',20,33,45,80,6.0,7.2,'Red','Full','Kharif','Low',180,'N',500,60,10,35);
INSERT INTO seed_variety VALUES (164,'White Bitter Gourd',17,33,50,80,6.0,7.2,'Loamy','Full','Summer','Medium',85,'N',500,40,10,35);
INSERT INTO seed_variety VALUES (165,'Pole Bean',16,32,45,80,6.0,6.8,'Loamy','Full','Kharif','Medium',75,'N',500,40,10,35);
INSERT INTO seed_variety VALUES (166,'Chilli Kanthari',20,34,50,80,6.0,7.2,'Red','Full','Kharif','Medium',160,'Y',40,10,10,35);
INSERT INTO seed_variety VALUES (167,'Chilli Ramnad Mundu',18,32,55,80,5.8,6.8,'Red','Full','Kharif','Medium',165,'Y',25,10,10,35);
INSERT INTO seed_variety VALUES (168,'Red Okra',17,34,55,85,6.0,7.0,'Loamy','Full','Summer','Medium',65,'Y',25,15,10,35);
INSERT INTO seed_variety VALUES (169,'Mattu Gulla Brinjal',18,34,50,85,6.0,7.0,'Loamy','Full','Summer','Medium',120,'Y',25,12,10,35);
INSERT INTO seed_variety VALUES (170,'Tomato Heirloom Brandywine',16,31,55,80,6.2,6.8,'Loamy','Full','Summer','Medium',90,'Y',50,12,10,35);
INSERT INTO seed_variety VALUES (171,'Brussels Sprouts',16,31,50,80,5.8,6.8,'Loamy','Full','Rabi','High',100,'Y',50,12,10,35);
INSERT INTO seed_variety VALUES (172,'Leek',17,30,55,75,6.0,7.0,'Loamy','Full','Rabi','Medium',120,'Y',40,15,10,35);
INSERT INTO seed_variety VALUES (173,'Habanero Chilli',18,32,50,80,6.0,7.2,'Red','Full','Kharif','Medium',110,'Y',40,12,10,35);
INSERT INTO seed_variety VALUES (174,'Purple Cabbage',19,31,50,80,6.0,6.8,'Loamy','Full','Rabi','High',95,'Y',25,15,10,35);
INSERT INTO seed_variety VALUES (175,'Yardlong Bean',18,34,50,80,6.2,7.0,'Loamy','Full','Summer','Medium',65,'Y',30,10,10,35);
INSERT INTO seed_variety VALUES (176,'Artichoke',18,32,50,85,6.2,7.0,'Loamy','Full','Rabi','Medium',150,'Y',3,5,10,35);
INSERT INTO seed_variety VALUES (177,'Celeriac',19,31,45,80,5.8,6.8,'Loamy','Full','Rabi','High',120,'Y',3,3,10,35);
INSERT INTO seed_variety VALUES (178,'Tomatillo',20,33,50,80,6.2,7.2,'Loamy','Full','Summer','Medium',90,'Y',3,3,10,35);
INSERT INTO seed_variety VALUES (179,'Chilli Bhut Jolokia',19,30,45,80,5.8,6.8,'Red','Full','Kharif','Medium',170,'Y',8,5,10,35);
INSERT INTO seed_variety VALUES (180,'Romanesco Cauliflower',18,33,50,80,6.2,7.0,'Loamy','Full','Rabi','High',90,'Y',8,3,10,35);
INSERT INTO seed_variety VALUES (181,'Thai Eggplant',18,34,50,75,6.0,7.2,'Loamy','Full','Summer','Medium',100,'Y',5,5,10,35);
INSERT INTO seed_variety VALUES (182,'Amaranthus Thandu Keerai',12,25,55,80,5.8,6.8,'Loamy','Partial','Summer','Medium',35,'N',1000,100,10,40);
INSERT INTO seed_variety VALUES (183,'Amaranthus Mulai Keerai',8,26,55,85,6.0,7.2,'Loamy','Partial','Summer','Medium',25,'N',1000,100,10,40);
INSERT INTO seed_variety VALUES (184,'Amaranthus Arai Keerai',10,25,55,80,5.8,6.8,'Loamy','Partial','Summer','Medium',30,'N',1000,120,10,40);
INSERT INTO seed_variety VALUES (185,'Coriander',9,27,45,85,6.2,7.0,'Loamy','Partial','Rabi','Medium',40,'N',1000,100,10,40);
INSERT INTO seed_variety VALUES (186,'Fenugreek Methi',8,26,50,80,6.0,6.8,'Loamy','Partial','Rabi','Medium',35,'N',1000,100,10,40);
INSERT INTO seed_variety VALUES (187,'Palak Beet Leaf',9,24,50,85,6.2,7.2,'Loamy','Partial','Rabi','Medium',40,'N',1000,100,10,40);
INSERT INTO seed_variety VALUES (188,'Lettuce',12,26,50,75,5.8,7.2,'Loamy','Partial','Rabi','Medium',50,'N',1000,150,10,40);
INSERT INTO seed_variety VALUES (189,'Dill Leaf',8,25,50,80,6.0,7.2,'Loamy','Partial','Rabi','Medium',45,'N',1000,150,10,40);
INSERT INTO seed_variety VALUES (190,'Swiss Chard',11,28,50,80,6.0,7.0,'Loamy','Partial','Rabi','Medium',55,'N',500,40,10,40);
INSERT INTO seed_variety VALUES (191,'Pak Choi Bok Choy',8,27,50,80,6.0,7.2,'Loamy','Partial','Rabi','Medium',45,'N',500,50,10,40);
INSERT INTO seed_variety VALUES (192,'Rocket Arugula',11,25,50,75,6.2,7.2,'Loamy','Partial','Rabi','Low',40,'N',500,40,10,40);
INSERT INTO seed_variety VALUES (193,'Roselle Pulicha Keerai',9,25,50,85,6.0,6.8,'Loamy','Partial','Kharif','Medium',90,'N',500,50,10,40);
INSERT INTO seed_variety VALUES (194,'Gongura Sorrel',12,27,55,85,6.2,7.2,'Loamy','Partial','Kharif','Medium',75,'N',500,60,10,40);
INSERT INTO seed_variety VALUES (195,'Siru Keerai',9,28,50,80,6.0,7.0,'Loamy','Partial','Summer','Low',30,'N',500,70,10,40);
INSERT INTO seed_variety VALUES (196,'Agathi Keerai',8,24,50,75,6.0,6.8,'Loamy','Partial','Kharif','Medium',60,'N',500,40,10,40);
INSERT INTO seed_variety VALUES (197,'Celery',10,26,45,80,6.0,7.0,'Loamy','Partial','Rabi','High',100,'N',500,60,10,40);
INSERT INTO seed_variety VALUES (198,'Kale',8,25,50,85,5.8,7.2,'Loamy','Partial','Rabi','Medium',60,'Y',20,15,10,40);
INSERT INTO seed_variety VALUES (199,'Mizuna',8,26,50,85,6.0,6.8,'Loamy','Partial','Rabi','Medium',40,'Y',40,15,10,40);
INSERT INTO seed_variety VALUES (200,'Komatsuna',10,26,55,80,6.0,6.8,'Loamy','Partial','Rabi','Medium',40,'Y',25,12,10,40);
INSERT INTO seed_variety VALUES (201,'Purslane Paruppu Keerai',10,26,55,85,6.0,6.8,'Sandy','Partial','Summer','Low',40,'Y',50,15,10,40);
INSERT INTO seed_variety VALUES (202,'Radicchio',10,26,55,85,6.0,7.2,'Loamy','Partial','Rabi','Medium',60,'Y',4,3,10,40);
INSERT INTO seed_variety VALUES (203,'Endive',8,27,45,80,6.2,7.0,'Loamy','Partial','Rabi','Medium',70,'Y',3,5,10,40);
INSERT INTO seed_variety VALUES (204,'Cumin',16,30,50,70,5.7,7.0,'Loamy','Full','Rabi','Low',110,'N',1000,120,15,35);
INSERT INTO seed_variety VALUES (205,'Fennel',17,31,50,75,5.5,7.0,'Loamy','Full','Rabi','Low',150,'N',1000,100,15,35);
INSERT INTO seed_variety VALUES (206,'Ajwain',20,32,45,70,5.5,6.8,'Loamy','Full','Rabi','Low',140,'N',1000,100,15,35);
INSERT INTO seed_variety VALUES (207,'Black Mustard',18,31,40,70,5.3,6.8,'Loamy','Full','Rabi','Low',100,'N',1000,150,15,35);
INSERT INTO seed_variety VALUES (208,'Fenugreek Seed',18,34,45,75,5.7,7.0,'Loamy','Full','Rabi','Low',110,'N',1000,100,15,35);
INSERT INTO seed_variety VALUES (209,'Coriander Seed',19,34,40,80,5.5,7.2,'Loamy','Full','Rabi','Low',100,'N',1000,150,15,35);
INSERT INTO seed_variety VALUES (210,'Tulsi Rama',18,32,40,70,5.5,7.2,'Loamy','Full','Kharif','Medium',90,'N',1000,120,15,35);
INSERT INTO seed_variety VALUES (211,'Sweet Basil',20,32,45,80,5.5,7.0,'Loamy','Full','Summer','Medium',60,'N',1000,120,15,35);
INSERT INTO seed_variety VALUES (212,'Nigella Kalonji',16,33,50,70,5.7,7.0,'Loamy','Full','Rabi','Low',140,'N',1000,120,15,35);
INSERT INTO seed_variety VALUES (213,'Dill Seed',19,34,45,75,5.3,7.2,'Loamy','Full','Rabi','Low',110,'N',500,60,15,35);
INSERT INTO seed_variety VALUES (214,'Celery Seed',17,32,40,75,5.7,7.2,'Loamy','Full','Rabi','Medium',150,'N',500,40,15,35);
INSERT INTO seed_variety VALUES (215,'Tulsi Krishna',18,34,50,75,5.7,6.8,'Loamy','Full','Kharif','Medium',90,'N',500,60,15,35);
INSERT INTO seed_variety VALUES (216,'Isabgol Psyllium',16,30,40,70,5.7,7.2,'Sandy','Full','Rabi','Low',120,'N',500,40,15,35);
INSERT INTO seed_variety VALUES (217,'Sabja Seeds',19,31,50,80,5.5,7.0,'Loamy','Full','Summer','Medium',80,'N',500,40,15,35);
INSERT INTO seed_variety VALUES (218,'Senna',18,34,45,70,5.7,7.0,'Sandy','Full','Kharif','Low',120,'N',500,60,15,35);
INSERT INTO seed_variety VALUES (219,'Ashwagandha',20,31,45,80,5.7,7.0,'Red','Full','Rabi','Low',150,'N',500,50,15,35);
INSERT INTO seed_variety VALUES (220,'Kalmegh',17,30,45,75,5.5,7.0,'Loamy','Full','Kharif','Medium',120,'N',500,70,15,35);
INSERT INTO seed_variety VALUES (221,'Stevia',20,32,45,75,5.7,7.2,'Loamy','Full','Summer','Medium',120,'Y',40,12,15,35);
INSERT INTO seed_variety VALUES (222,'Thyme',19,33,45,80,5.3,7.0,'Sandy','Full','Rabi','Low',100,'Y',50,12,15,35);
INSERT INTO seed_variety VALUES (223,'Oregano',17,32,45,75,5.5,7.2,'Sandy','Full','Summer','Low',90,'Y',50,12,15,35);
INSERT INTO seed_variety VALUES (224,'Rosemary',17,34,40,70,5.5,7.0,'Sandy','Full','Rabi','Low',150,'Y',25,15,15,35);
INSERT INTO seed_variety VALUES (225,'Lemon Balm',17,33,50,75,5.7,7.2,'Loamy','Full','Summer','Medium',90,'Y',30,12,15,35);
INSERT INTO seed_variety VALUES (226,'Chives',19,34,50,75,5.5,7.0,'Loamy','Full','Rabi','Medium',80,'Y',25,10,15,35);
INSERT INTO seed_variety VALUES (227,'Parsley',18,32,40,70,5.7,7.0,'Loamy','Full','Rabi','Medium',75,'Y',40,12,15,35);
INSERT INTO seed_variety VALUES (228,'Borage',18,32,45,80,5.3,7.0,'Loamy','Full','Summer','Medium',60,'Y',25,15,15,35);
INSERT INTO seed_variety VALUES (229,'Sage',17,31,45,80,5.7,6.8,'Sandy','Full','Rabi','Low',120,'Y',30,10,15,35);
INSERT INTO seed_variety VALUES (230,'Vana Tulsi',18,32,50,75,5.5,7.0,'Loamy','Full','Kharif','Medium',90,'Y',30,12,15,35);
INSERT INTO seed_variety VALUES (231,'Cardamom',16,34,50,70,5.3,6.8,'Loamy','Full','Kharif','High',730,'Y',3,4,15,35);
INSERT INTO seed_variety VALUES (232,'Cotton Hybrid',21,33,50,80,6.2,8.2,'Black','Full','Kharif','Medium',160,'N',1000,120,15,35);
INSERT INTO seed_variety VALUES (233,'Cotton MCU 5',19,35,50,80,6.0,8.0,'Black','Full','Kharif','Medium',160,'N',1000,100,15,35);
INSERT INTO seed_variety VALUES (234,'Cotton Suvin',20,34,50,80,6.0,8.2,'Black','Full','Kharif','Medium',170,'N',500,50,15,35);
INSERT INTO seed_variety VALUES (235,'Jute',22,35,50,85,5.8,8.0,'Loamy','Full','Kharif','High',120,'N',500,50,15,35);
INSERT INTO seed_variety VALUES (236,'Kenaf Mesta',22,37,50,80,6.0,8.2,'Loamy','Full','Kharif','Medium',130,'N',500,60,15,35);
INSERT INTO seed_variety VALUES (237,'Flax Fibre',21,33,55,80,6.0,8.0,'Loamy','Full','Rabi','Medium',110,'Y',25,12,15,35);
INSERT INTO seed_variety VALUES (238,'Cotton Karunganni Desi',21,34,50,75,6.0,7.8,'Black','Full','Kharif','Low',170,'Y',8,3,15,35);
INSERT INTO seed_variety VALUES (239,'Marigold African',15,28,55,70,5.8,7.0,'Loamy','Full','Rabi','Medium',75,'N',1000,150,10,35);
INSERT INTO seed_variety VALUES (240,'Marigold French',13,28,45,80,6.0,6.8,'Loamy','Full','Rabi','Medium',65,'N',1000,150,10,35);
INSERT INTO seed_variety VALUES (241,'Zinnia',17,30,50,75,6.0,7.2,'Loamy','Full','Summer','Medium',60,'N',1000,100,10,35);
INSERT INTO seed_variety VALUES (242,'Cosmos',17,30,45,75,5.8,7.0,'Loamy','Full','Rabi','Medium',70,'N',1000,150,10,35);
INSERT INTO seed_variety VALUES (243,'Celosia Cockscomb',15,30,45,70,5.8,6.8,'Loamy','Full','Kharif','Medium',80,'N',1000,120,10,35);
INSERT INTO seed_variety VALUES (244,'Crossandra Kanakambaram',15,29,50,70,5.8,7.2,'Red','Full','Summer','Medium',120,'N',500,40,10,35);
INSERT INTO seed_variety VALUES (245,'Gomphrena Globe Amaranth',15,32,45,70,6.0,7.0,'Loamy','Full','Summer','Low',70,'N',500,70,10,35);
INSERT INTO seed_variety VALUES (246,'Balsam',15,31,45,70,5.8,6.8,'Loamy','Full','Kharif','Medium',60,'N',500,50,10,35);
INSERT INTO seed_variety VALUES (247,'China Aster',14,29,50,75,6.0,7.0,'Loamy','Full','Rabi','Medium',90,'N',500,60,10,35);
INSERT INTO seed_variety VALUES (248,'Nasturtium',15,29,50,80,6.0,6.8,'Loamy','Full','Rabi','Medium',55,'N',500,60,10,35);
INSERT INTO seed_variety VALUES (249,'Mirabilis Jalapa',17,29,45,75,5.8,7.2,'Loamy','Full','Kharif','Medium',70,'N',500,70,10,35);
INSERT INTO seed_variety VALUES (250,'Salvia',17,31,50,75,6.2,7.0,'Loamy','Full','Rabi','Medium',75,'N',500,70,10,35);
INSERT INTO seed_variety VALUES (251,'Vinca Periwinkle',13,30,50,80,6.0,6.8,'Loamy','Full','Summer','Low',80,'N',500,70,10,35);
INSERT INTO seed_variety VALUES (252,'Sunflower Ornamental',15,29,50,75,5.8,7.0,'Loamy','Full','Summer','Medium',70,'N',500,60,10,35);
INSERT INTO seed_variety VALUES (253,'Petunia',17,28,50,75,6.0,7.0,'Loamy','Full','Rabi','Medium',90,'Y',25,12,10,35);
INSERT INTO seed_variety VALUES (254,'Hollyhock',17,28,45,70,6.0,7.0,'Loamy','Full','Rabi','Medium',120,'Y',30,10,10,35);
INSERT INTO seed_variety VALUES (255,'Sweet William',15,29,55,70,6.2,7.0,'Loamy','Full','Rabi','Medium',90,'Y',30,15,10,35);
INSERT INTO seed_variety VALUES (256,'Snapdragon',15,31,50,75,6.2,7.0,'Loamy','Full','Rabi','Medium',90,'Y',50,12,10,35);
INSERT INTO seed_variety VALUES (257,'Larkspur',17,32,50,75,5.8,6.8,'Loamy','Full','Rabi','Medium',100,'Y',30,15,10,35);
INSERT INTO seed_variety VALUES (258,'Cornflower',15,30,45,70,6.0,7.2,'Loamy','Full','Rabi','Low',80,'Y',40,15,10,35);
INSERT INTO seed_variety VALUES (259,'Cleome Spider Flower',15,30,55,75,5.8,7.0,'Loamy','Full','Summer','Low',75,'Y',20,12,10,35);
INSERT INTO seed_variety VALUES (260,'Lisianthus',15,29,50,75,6.2,7.0,'Loamy','Full','Rabi','Medium',140,'Y',4,4,10,35);
INSERT INTO seed_variety VALUES (261,'Delphinium',14,29,50,75,6.0,7.2,'Loamy','Full','Rabi','Medium',110,'Y',4,5,10,35);
INSERT INTO seed_variety VALUES (262,'Sunnhemp',21,34,40,80,5.3,8.2,'Loamy','Full','Kharif','Low',50,'N',1000,100,20,30);
INSERT INTO seed_variety VALUES (263,'Dhaincha',21,35,40,75,5.7,8.2,'Clay','Full','Kharif','Medium',55,'N',1000,120,20,30);
INSERT INTO seed_variety VALUES (264,'Fodder Cowpea',19,35,40,80,5.3,8.2,'Sandy','Full','Summer','Low',60,'N',1000,150,20,30);
INSERT INTO seed_variety VALUES (265,'Fodder Maize African Tall',19,37,35,80,5.7,8.0,'Loamy','Full','Kharif','Medium',65,'N',1000,100,20,30);
INSERT INTO seed_variety VALUES (266,'Sudan Grass',19,35,45,80,5.3,8.0,'Sandy','Full','Summer','Low',60,'N',1000,100,20,30);
INSERT INTO seed_variety VALUES (267,'Fodder Sorghum CO FS 29',22,35,40,75,5.5,8.0,'Black','Full','Kharif','Medium',65,'N',1000,150,20,30);
INSERT INTO seed_variety VALUES (268,'Lucerne Alfalfa',20,35,45,80,5.5,8.0,'Loamy','Full','Rabi','Medium',90,'N',500,50,20,30);
INSERT INTO seed_variety VALUES (269,'Berseem',20,34,45,85,5.5,8.2,'Loamy','Full','Rabi','High',60,'N',500,40,20,30);
INSERT INTO seed_variety VALUES (270,'Stylosanthes',19,35,35,80,5.3,7.8,'Red','Full','Kharif','Low',120,'N',500,60,20,30);
INSERT INTO seed_variety VALUES (271,'Desmanthus',19,37,40,75,5.3,8.0,'Red','Full','Kharif','Low',120,'N',500,50,20,30);
INSERT INTO seed_variety VALUES (272,'Subabul Leucaena',18,35,35,85,5.5,7.8,'Red','Full','Kharif','Low',365,'N',500,40,20,30);
INSERT INTO seed_variety VALUES (273,'Guinea Grass',19,35,35,80,5.3,7.8,'Loamy','Full','Kharif','Medium',75,'N',500,40,20,30);
INSERT INTO seed_variety VALUES (274,'Rhodes Grass',20,33,40,80,5.5,7.8,'Sandy','Full','Summer','Low',80,'Y',50,10,20,30);
INSERT INTO seed_variety VALUES (275,'Gliricidia Seed',20,34,45,80,5.5,7.8,'Red','Full','Kharif','Low',365,'Y',20,15,20,30);
INSERT INTO seed_variety VALUES (276,'Cenchrus Anjan Grass',22,33,45,75,5.7,7.8,'Sandy','Full','Kharif','Low',90,'Y',50,10,20,30);
INSERT INTO seed_variety VALUES (277,'Papaya Red Lady',20,35,55,85,6.0,7.3,'Loamy','Full','Summer','Medium',270,'N',1000,150,15,35);
INSERT INTO seed_variety VALUES (278,'Neem',22,35,50,75,6.0,7.5,'Red','Full','Kharif','Low',365,'N',1000,100,15,35);
INSERT INTO seed_variety VALUES (279,'Pongamia Honge',22,35,50,80,6.0,7.3,'Red','Full','Kharif','Low',365,'N',500,40,15,35);
INSERT INTO seed_variety VALUES (280,'Teak',21,35,45,80,6.0,7.7,'Loamy','Full','Kharif','Medium',365,'N',500,60,15,35);
INSERT INTO seed_variety VALUES (281,'Tamarind',22,34,50,75,6.0,7.3,'Red','Full','Kharif','Low',365,'N',500,60,15,35);
INSERT INTO seed_variety VALUES (282,'Jujube Ber',20,35,50,80,6.2,7.3,'Sandy','Full','Kharif','Low',240,'N',500,70,15,35);
INSERT INTO seed_variety VALUES (283,'Custard Apple Sitaphal',20,34,55,80,5.8,7.3,'Red','Full','Kharif','Low',365,'N',500,40,15,35);
INSERT INTO seed_variety VALUES (284,'Amla Aonla',22,36,45,80,6.0,7.7,'Loamy','Full','Kharif','Medium',365,'N',500,70,15,35);
INSERT INTO seed_variety VALUES (285,'Palmyra Palm Seed',18,37,50,80,6.0,7.5,'Sandy','Full','Kharif','Low',365,'N',500,40,15,35);
INSERT INTO seed_variety VALUES (286,'Curry Leaf Seed',20,35,50,80,5.8,7.5,'Loamy','Full','Kharif','Medium',365,'N',500,40,15,35);
INSERT INTO seed_variety VALUES (287,'Jamun Black Plum',21,37,50,85,6.2,7.7,'Loamy','Full','Kharif','Medium',365,'Y',40,12,15,35);
INSERT INTO seed_variety VALUES (288,'Passion Fruit',22,36,50,85,5.8,7.7,'Loamy','Full','Summer','High',240,'Y',30,15,15,35);
INSERT INTO seed_variety VALUES (289,'Mahogany',18,37,55,85,6.0,7.5,'Loamy','Full','Kharif','Medium',365,'Y',20,10,15,35);
INSERT INTO seed_variety VALUES (290,'Rudraksha Tree',18,37,50,75,5.8,7.7,'Loamy','Full','Kharif','High',365,'Y',4,4,15,35);

-- Batches: audit trigger is switched off while loading so the audit log starts clean.
ALTER TRIGGER trg_batch_audit DISABLE;
-- batch_id, seed, qty, collected, expiry, germ, origin, parent, unit
INSERT INTO seed_batch VALUES (1,1,500,SYSDATE-60,SYSDATE+300,92,'Madurai farmers coop',NULL,2);
INSERT INTO seed_batch VALUES (2,2,350,SYSDATE-90,SYSDATE+200,88,'Coimbatore farm',NULL,2);
INSERT INTO seed_batch VALUES (3,3,420,SYSDATE-30,SYSDATE+15,81,'Thanjavur farm',NULL,2);
INSERT INTO seed_batch VALUES (4,4,200,SYSDATE-45,SYSDATE+250,80,'Sivakasi farm',NULL,1);
INSERT INTO seed_batch VALUES (5,5,60,SYSDATE-20,SYSDATE+180,95,'Seed lab',NULL,1);
INSERT INTO seed_batch VALUES (6,6,300,SYSDATE-100,SYSDATE+400,90,'Hill farm',NULL,3);
INSERT INTO seed_batch VALUES (7,7,150,SYSDATE-70,SYSDATE+120,84,'Madurai farm',NULL,2);
INSERT INTO seed_batch VALUES (8,8,40,SYSDATE-10,SYSDATE+90,93,'Seed lab',NULL,1);
INSERT INTO seed_batch VALUES (9,9,15,SYSDATE-40,SYSDATE+365,89,'Heritage growers',NULL,2);
INSERT INTO seed_batch VALUES (10,1,80,SYSDATE-5,SYSDATE+360,94,'Regenerated from batch 1',1,2);


-- one batch for every extended variety (batch ids 11-291), plus 5 regenerated batches (292-296)
INSERT INTO seed_batch VALUES (11,10,780,SYSDATE-32,SYSDATE+650,91,'Sivakasi farm',NULL,1);
INSERT INTO seed_batch VALUES (12,11,815,SYSDATE-134,SYSDATE+481,93,'Seed lab',NULL,1);
INSERT INTO seed_batch VALUES (13,12,555,SYSDATE-168,SYSDATE+378,88,'Thoothukudi farm',NULL,1);
INSERT INTO seed_batch VALUES (14,13,840,SYSDATE-92,SYSDATE+385,94,'Chennai seed lab',NULL,1);
INSERT INTO seed_batch VALUES (15,14,845,SYSDATE-125,SYSDATE+559,94,'Madurai farmers coop',NULL,1);
INSERT INTO seed_batch VALUES (16,15,845,SYSDATE-146,SYSDATE+539,91,'Sivakasi farm',NULL,1);
INSERT INTO seed_batch VALUES (17,16,280,SYSDATE-67,SYSDATE+464,96,'Chennai seed lab',NULL,1);
INSERT INTO seed_batch VALUES (18,17,465,SYSDATE-81,SYSDATE+370,92,'Seed lab',NULL,1);
INSERT INTO seed_batch VALUES (19,18,580,SYSDATE-68,SYSDATE+439,95,'Sivakasi farm',NULL,1);
INSERT INTO seed_batch VALUES (20,19,715,SYSDATE-96,SYSDATE+344,89,'Sivakasi farm',NULL,1);
INSERT INTO seed_batch VALUES (21,20,510,SYSDATE-124,SYSDATE+418,88,'Thoothukudi farm',NULL,1);
INSERT INTO seed_batch VALUES (22,21,515,SYSDATE-112,SYSDATE+365,96,'Seed lab',NULL,1);
INSERT INTO seed_batch VALUES (23,22,115,SYSDATE-119,SYSDATE+440,93,'Seed lab',NULL,1);
INSERT INTO seed_batch VALUES (24,23,230,SYSDATE-59,SYSDATE+380,91,'Madurai farmers coop',NULL,1);
INSERT INTO seed_batch VALUES (25,24,140,SYSDATE-85,SYSDATE+261,93,'Hill farm',NULL,1);
INSERT INTO seed_batch VALUES (26,25,115,SYSDATE-86,SYSDATE+426,86,'Coimbatore farm',NULL,1);
INSERT INTO seed_batch VALUES (27,26,215,SYSDATE-25,SYSDATE+555,89,'Thanjavur farm',NULL,1);
INSERT INTO seed_batch VALUES (28,27,60,SYSDATE-34,SYSDATE+667,85,'Farmer seed keepers',NULL,1);
INSERT INTO seed_batch VALUES (29,28,8,SYSDATE-80,SYSDATE+806,95,'Heritage growers',NULL,1);
INSERT INTO seed_batch VALUES (30,29,56,SYSDATE-138,SYSDATE+436,89,'Hill farm',NULL,1);
INSERT INTO seed_batch VALUES (31,30,31,SYSDATE-55,SYSDATE+582,86,'Farmer seed keepers',NULL,1);
INSERT INTO seed_batch VALUES (32,31,32,SYSDATE-27,SYSDATE+666,86,'Farmer seed keepers',NULL,1);
INSERT INTO seed_batch VALUES (33,32,42,SYSDATE-124,SYSDATE+596,88,'Heritage growers',NULL,1);
INSERT INTO seed_batch VALUES (34,33,6,SYSDATE-36,SYSDATE+504,93,'Farmer seed keepers',NULL,1);
INSERT INTO seed_batch VALUES (35,34,2,SYSDATE-124,SYSDATE+630,90,'Hill farm',NULL,1);
INSERT INTO seed_batch VALUES (36,35,13,SYSDATE-115,SYSDATE+500,85,'Hill farm',NULL,1);
INSERT INTO seed_batch VALUES (37,36,12,SYSDATE-128,SYSDATE+790,85,'Heritage growers',NULL,1);
INSERT INTO seed_batch VALUES (38,37,10,SYSDATE-122,SYSDATE+442,94,'Heritage growers',NULL,1);
INSERT INTO seed_batch VALUES (39,38,12,SYSDATE-35,SYSDATE+504,94,'Heritage growers',NULL,1);
INSERT INTO seed_batch VALUES (40,39,13,SYSDATE-105,SYSDATE+801,89,'Farmer seed keepers',NULL,1);
INSERT INTO seed_batch VALUES (41,40,9,SYSDATE-134,SYSDATE+438,93,'Heritage growers',NULL,1);
INSERT INTO seed_batch VALUES (42,41,11,SYSDATE-83,SYSDATE+456,88,'Farmer seed keepers',NULL,1);
INSERT INTO seed_batch VALUES (43,42,9,SYSDATE-41,SYSDATE+773,94,'Heritage growers',NULL,1);
INSERT INTO seed_batch VALUES (44,43,12,SYSDATE-84,SYSDATE+889,88,'Heritage growers',NULL,1);
INSERT INTO seed_batch VALUES (45,44,9,SYSDATE-150,SYSDATE+759,94,'Heritage growers',NULL,1);
INSERT INTO seed_batch VALUES (46,45,6,SYSDATE-132,SYSDATE+672,89,'Hill farm',NULL,1);
INSERT INTO seed_batch VALUES (47,46,8,SYSDATE-145,SYSDATE+675,87,'Heritage growers',NULL,1);
INSERT INTO seed_batch VALUES (48,47,10,SYSDATE-42,SYSDATE+764,94,'Hill farm',NULL,1);
INSERT INTO seed_batch VALUES (49,48,6,SYSDATE-44,SYSDATE+719,85,'Heritage growers',NULL,1);
INSERT INTO seed_batch VALUES (50,49,890,SYSDATE-65,SYSDATE+448,90,'Madurai farmers coop',NULL,3);
INSERT INTO seed_batch VALUES (51,50,850,SYSDATE-125,SYSDATE+307,96,'Seed lab',NULL,3);
INSERT INTO seed_batch VALUES (52,51,600,SYSDATE-65,SYSDATE+473,92,'Chennai seed lab',NULL,3);
INSERT INTO seed_batch VALUES (53,52,670,SYSDATE-42,SYSDATE+460,90,'Sivakasi farm',NULL,3);
INSERT INTO seed_batch VALUES (54,53,530,SYSDATE-75,SYSDATE+624,94,'Madurai farmers coop',NULL,3);
INSERT INTO seed_batch VALUES (55,54,640,SYSDATE-81,SYSDATE+505,91,'Madurai farmers coop',NULL,3);
INSERT INTO seed_batch VALUES (56,55,420,SYSDATE-154,SYSDATE+472,97,'Thoothukudi farm',NULL,3);
INSERT INTO seed_batch VALUES (57,56,400,SYSDATE-101,SYSDATE+297,91,'Hill farm',NULL,3);
INSERT INTO seed_batch VALUES (58,57,315,SYSDATE-42,SYSDATE+559,96,'Thanjavur farm',NULL,3);
INSERT INTO seed_batch VALUES (59,58,785,SYSDATE-168,SYSDATE+265,93,'Hill farm',NULL,3);
INSERT INTO seed_batch VALUES (60,59,215,SYSDATE-100,SYSDATE+406,87,'Hill farm',NULL,3);
INSERT INTO seed_batch VALUES (61,60,115,SYSDATE-169,SYSDATE+253,91,'Thanjavur farm',NULL,3);
INSERT INTO seed_batch VALUES (62,61,105,SYSDATE-53,SYSDATE+288,88,'Thanjavur farm',NULL,3);
INSERT INTO seed_batch VALUES (63,62,300,SYSDATE-158,SYSDATE+382,91,'Madurai farmers coop',NULL,3);
INSERT INTO seed_batch VALUES (64,63,105,SYSDATE-103,SYSDATE+484,86,'Thanjavur farm',NULL,3);
INSERT INTO seed_batch VALUES (65,64,38,SYSDATE-86,SYSDATE+498,90,'Seed lab',NULL,3);
INSERT INTO seed_batch VALUES (66,65,27,SYSDATE-93,SYSDATE+621,95,'Hill farm',NULL,3);
INSERT INTO seed_batch VALUES (67,66,54,SYSDATE-21,SYSDATE+583,89,'Farmer seed keepers',NULL,3);
INSERT INTO seed_batch VALUES (68,67,21,SYSDATE-145,SYSDATE+371,92,'Heritage growers',NULL,3);
INSERT INTO seed_batch VALUES (69,68,11,SYSDATE-95,SYSDATE+681,93,'Heritage growers',NULL,3);
INSERT INTO seed_batch VALUES (70,69,6,SYSDATE-131,SYSDATE+402,91,'Heritage growers',NULL,3);
INSERT INTO seed_batch VALUES (71,70,460,SYSDATE-110,SYSDATE+577,88,'Thanjavur farm',NULL,2);
INSERT INTO seed_batch VALUES (72,71,845,SYSDATE-180,SYSDATE+360,91,'Madurai farmers coop',NULL,2);
INSERT INTO seed_batch VALUES (73,72,40,SYSDATE-147,SYSDATE+521,89,'Hill farm',NULL,2);
INSERT INTO seed_batch VALUES (74,73,450,SYSDATE-92,SYSDATE+503,94,'Thanjavur farm',NULL,2);
INSERT INTO seed_batch VALUES (75,74,870,SYSDATE-96,SYSDATE+12,88,'Madurai farmers coop',NULL,2);
INSERT INTO seed_batch VALUES (76,75,605,SYSDATE-152,SYSDATE+524,97,'Hill farm',NULL,2);
INSERT INTO seed_batch VALUES (77,76,290,SYSDATE-74,SYSDATE+322,94,'Thanjavur farm',NULL,2);
INSERT INTO seed_batch VALUES (78,77,210,SYSDATE-119,SYSDATE+422,94,'Seed lab',NULL,2);
INSERT INTO seed_batch VALUES (79,78,250,SYSDATE-176,SYSDATE+341,88,'Thanjavur farm',NULL,2);
INSERT INTO seed_batch VALUES (80,79,260,SYSDATE-158,SYSDATE+219,90,'Thoothukudi farm',NULL,2);
INSERT INTO seed_batch VALUES (81,80,24,SYSDATE-68,SYSDATE+447,93,'Farmer seed keepers',NULL,2);
INSERT INTO seed_batch VALUES (82,81,48,SYSDATE-34,SYSDATE+370,94,'Hill farm',NULL,2);
INSERT INTO seed_batch VALUES (83,82,18,SYSDATE-22,SYSDATE+712,94,'Heritage growers',NULL,2);
INSERT INTO seed_batch VALUES (84,83,55,SYSDATE-68,SYSDATE+471,90,'Heritage growers',NULL,2);
INSERT INTO seed_batch VALUES (85,84,370,SYSDATE-77,SYSDATE+546,91,'Sivakasi farm',NULL,2);
INSERT INTO seed_batch VALUES (86,85,785,SYSDATE-165,SYSDATE+398,90,'Madurai farmers coop',NULL,2);
INSERT INTO seed_batch VALUES (87,86,635,SYSDATE-90,SYSDATE+298,92,'Seed lab',NULL,2);
INSERT INTO seed_batch VALUES (88,87,740,SYSDATE-81,SYSDATE+546,89,'Madurai farmers coop',NULL,2);
INSERT INTO seed_batch VALUES (89,88,310,SYSDATE-92,SYSDATE+438,91,'Thoothukudi farm',NULL,2);
INSERT INTO seed_batch VALUES (90,89,695,SYSDATE-73,SYSDATE+588,93,'Chennai seed lab',NULL,2);
INSERT INTO seed_batch VALUES (91,90,30,SYSDATE-50,SYSDATE+351,94,'Sivakasi farm',NULL,2);
INSERT INTO seed_batch VALUES (92,91,835,SYSDATE-137,SYSDATE+500,97,'Hill farm',NULL,2);
INSERT INTO seed_batch VALUES (93,92,815,SYSDATE-86,SYSDATE+465,90,'Madurai farmers coop',NULL,2);
INSERT INTO seed_batch VALUES (94,93,455,SYSDATE-64,SYSDATE+353,89,'Madurai farmers coop',NULL,2);
INSERT INTO seed_batch VALUES (95,94,325,SYSDATE-94,SYSDATE+267,96,'Coimbatore farm',NULL,2);
INSERT INTO seed_batch VALUES (96,95,250,SYSDATE-84,SYSDATE+369,95,'Seed lab',NULL,2);
INSERT INTO seed_batch VALUES (97,96,530,SYSDATE-131,SYSDATE+365,94,'Coimbatore farm',NULL,2);
INSERT INTO seed_batch VALUES (98,97,760,SYSDATE-129,SYSDATE+257,90,'Sivakasi farm',NULL,2);
INSERT INTO seed_batch VALUES (99,98,135,SYSDATE-56,SYSDATE+535,95,'Sivakasi farm',NULL,2);
INSERT INTO seed_batch VALUES (100,99,190,SYSDATE-141,SYSDATE+262,92,'Sivakasi farm',NULL,2);
INSERT INTO seed_batch VALUES (101,100,215,SYSDATE-65,SYSDATE+394,94,'Thanjavur farm',NULL,2);
INSERT INTO seed_batch VALUES (102,101,160,SYSDATE-54,SYSDATE+253,95,'Sivakasi farm',NULL,2);
INSERT INTO seed_batch VALUES (103,102,90,SYSDATE-24,SYSDATE+338,94,'Sivakasi farm',NULL,2);
INSERT INTO seed_batch VALUES (104,103,205,SYSDATE-168,SYSDATE+265,96,'Chennai seed lab',NULL,2);
INSERT INTO seed_batch VALUES (105,104,42,SYSDATE-104,SYSDATE+523,86,'Hill farm',NULL,2);
INSERT INTO seed_batch VALUES (106,105,59,SYSDATE-28,SYSDATE+732,94,'Heritage growers',NULL,2);
INSERT INTO seed_batch VALUES (107,106,24,SYSDATE-121,SYSDATE+481,89,'Hill farm',NULL,2);
INSERT INTO seed_batch VALUES (108,107,36,SYSDATE-116,SYSDATE+780,93,'Hill farm',NULL,2);
INSERT INTO seed_batch VALUES (109,108,19,SYSDATE-121,SYSDATE+661,93,'Heritage growers',NULL,2);
INSERT INTO seed_batch VALUES (110,109,60,SYSDATE-150,SYSDATE+403,91,'Seed lab',NULL,2);
INSERT INTO seed_batch VALUES (111,110,665,SYSDATE-161,SYSDATE+440,90,'Madurai farmers coop',NULL,2);
INSERT INTO seed_batch VALUES (112,111,675,SYSDATE-142,SYSDATE+348,66,'Seed lab',NULL,2);
INSERT INTO seed_batch VALUES (113,112,895,SYSDATE-45,SYSDATE+614,93,'Coimbatore farm',NULL,2);
INSERT INTO seed_batch VALUES (114,113,640,SYSDATE-167,SYSDATE+315,92,'Sivakasi farm',NULL,2);
INSERT INTO seed_batch VALUES (115,114,820,SYSDATE-47,SYSDATE+493,97,'Sivakasi farm',NULL,2);
INSERT INTO seed_batch VALUES (116,115,305,SYSDATE-19,SYSDATE+350,88,'Sivakasi farm',NULL,2);
INSERT INTO seed_batch VALUES (117,116,675,SYSDATE-131,SYSDATE+538,91,'Sivakasi farm',NULL,2);
INSERT INTO seed_batch VALUES (118,117,265,SYSDATE-21,SYSDATE+474,92,'Madurai farmers coop',NULL,2);
INSERT INTO seed_batch VALUES (119,118,295,SYSDATE-149,SYSDATE+261,89,'Thoothukudi farm',NULL,2);
INSERT INTO seed_batch VALUES (120,119,105,SYSDATE-162,SYSDATE+207,88,'Hill farm',NULL,2);
INSERT INTO seed_batch VALUES (121,120,130,SYSDATE-74,SYSDATE+253,94,'Chennai seed lab',NULL,2);
INSERT INTO seed_batch VALUES (122,121,225,SYSDATE-23,SYSDATE+373,92,'Thanjavur farm',NULL,2);
INSERT INTO seed_batch VALUES (123,122,300,SYSDATE-91,SYSDATE+409,95,'Coimbatore farm',NULL,2);
INSERT INTO seed_batch VALUES (124,123,90,SYSDATE-37,SYSDATE+476,89,'Seed lab',NULL,2);
INSERT INTO seed_batch VALUES (125,124,21,SYSDATE-96,SYSDATE+675,86,'Heritage growers',NULL,2);
INSERT INTO seed_batch VALUES (126,125,23,SYSDATE-105,SYSDATE+779,90,'Farmer seed keepers',NULL,2);
INSERT INTO seed_batch VALUES (127,126,29,SYSDATE-90,SYSDATE+594,94,'Heritage growers',NULL,2);
INSERT INTO seed_batch VALUES (128,127,20,SYSDATE-66,SYSDATE+380,97,'Seed lab',NULL,1);
INSERT INTO seed_batch VALUES (129,128,655,SYSDATE-141,SYSDATE+358,90,'Hill farm',NULL,1);
INSERT INTO seed_batch VALUES (130,129,690,SYSDATE-53,SYSDATE+549,95,'Madurai farmers coop',NULL,1);
INSERT INTO seed_batch VALUES (131,130,720,SYSDATE-45,SYSDATE+553,91,'Sivakasi farm',NULL,1);
INSERT INTO seed_batch VALUES (132,131,745,SYSDATE-86,SYSDATE+399,96,'Madurai farmers coop',NULL,1);
INSERT INTO seed_batch VALUES (133,132,890,SYSDATE-40,SYSDATE+649,64,'Thanjavur farm',NULL,1);
INSERT INTO seed_batch VALUES (134,133,345,SYSDATE-179,SYSDATE+457,95,'Seed lab',NULL,1);
INSERT INTO seed_batch VALUES (135,134,660,SYSDATE-50,SYSDATE+343,94,'Thanjavur farm',NULL,1);
INSERT INTO seed_batch VALUES (136,135,395,SYSDATE-79,SYSDATE+532,97,'Sivakasi farm',NULL,1);
INSERT INTO seed_batch VALUES (137,136,570,SYSDATE-159,SYSDATE+201,90,'Coimbatore farm',NULL,1);
INSERT INTO seed_batch VALUES (138,137,720,SYSDATE-159,SYSDATE+444,94,'Seed lab',NULL,1);
INSERT INTO seed_batch VALUES (139,138,885,SYSDATE-159,SYSDATE+310,90,'Seed lab',NULL,1);
INSERT INTO seed_batch VALUES (140,139,470,SYSDATE-68,SYSDATE+466,89,'Sivakasi farm',NULL,1);
INSERT INTO seed_batch VALUES (141,140,550,SYSDATE-176,SYSDATE+452,88,'Sivakasi farm',NULL,1);
INSERT INTO seed_batch VALUES (142,141,765,SYSDATE-154,SYSDATE+534,95,'Thanjavur farm',NULL,1);
INSERT INTO seed_batch VALUES (143,142,520,SYSDATE-111,SYSDATE+347,90,'Seed lab',NULL,1);
INSERT INTO seed_batch VALUES (144,143,260,SYSDATE-90,SYSDATE+414,95,'Coimbatore farm',NULL,1);
INSERT INTO seed_batch VALUES (145,144,870,SYSDATE-106,SYSDATE+392,89,'Coimbatore farm',NULL,1);
INSERT INTO seed_batch VALUES (146,145,385,SYSDATE-55,SYSDATE+488,94,'Thanjavur farm',NULL,1);
INSERT INTO seed_batch VALUES (147,146,590,SYSDATE-25,SYSDATE+574,96,'Hill farm',NULL,1);
INSERT INTO seed_batch VALUES (148,147,670,SYSDATE-152,SYSDATE+241,89,'Chennai seed lab',NULL,1);
INSERT INTO seed_batch VALUES (149,148,530,SYSDATE-148,SYSDATE+503,96,'Seed lab',NULL,1);
INSERT INTO seed_batch VALUES (150,149,335,SYSDATE-148,SYSDATE+394,94,'Thanjavur farm',NULL,1);
INSERT INTO seed_batch VALUES (151,150,800,SYSDATE-164,SYSDATE+510,95,'Thanjavur farm',NULL,1);
INSERT INTO seed_batch VALUES (152,151,270,SYSDATE-89,SYSDATE+462,88,'Sivakasi farm',NULL,1);
INSERT INTO seed_batch VALUES (153,152,265,SYSDATE-95,SYSDATE+344,93,'Coimbatore farm',NULL,1);
INSERT INTO seed_batch VALUES (154,153,170,SYSDATE-137,SYSDATE+331,94,'Coimbatore farm',NULL,1);
INSERT INTO seed_batch VALUES (155,154,135,SYSDATE-34,SYSDATE+565,96,'Coimbatore farm',NULL,1);
INSERT INTO seed_batch VALUES (156,155,235,SYSDATE-60,SYSDATE+343,89,'Thoothukudi farm',NULL,1);
INSERT INTO seed_batch VALUES (157,156,195,SYSDATE-51,SYSDATE+461,95,'Seed lab',NULL,1);
INSERT INTO seed_batch VALUES (158,157,270,SYSDATE-28,SYSDATE+482,89,'Thoothukudi farm',NULL,1);
INSERT INTO seed_batch VALUES (159,158,200,SYSDATE-145,SYSDATE+419,95,'Madurai farmers coop',NULL,1);
INSERT INTO seed_batch VALUES (160,159,280,SYSDATE-81,SYSDATE+302,96,'Hill farm',NULL,1);
INSERT INTO seed_batch VALUES (161,160,90,SYSDATE-147,SYSDATE+445,90,'Thanjavur farm',NULL,1);
INSERT INTO seed_batch VALUES (162,161,300,SYSDATE-138,SYSDATE+321,92,'Thanjavur farm',NULL,1);
INSERT INTO seed_batch VALUES (163,162,195,SYSDATE-172,SYSDATE+302,88,'Thanjavur farm',NULL,1);
INSERT INTO seed_batch VALUES (164,163,220,SYSDATE-48,SYSDATE+471,91,'Seed lab',NULL,1);
INSERT INTO seed_batch VALUES (165,164,185,SYSDATE-175,SYSDATE+357,88,'Thanjavur farm',NULL,1);
INSERT INTO seed_batch VALUES (166,165,280,SYSDATE-174,SYSDATE+236,94,'Seed lab',NULL,1);
INSERT INTO seed_batch VALUES (167,166,33,SYSDATE-144,SYSDATE+745,95,'Heritage growers',NULL,1);
INSERT INTO seed_batch VALUES (168,167,43,SYSDATE-84,SYSDATE+568,89,'Heritage growers',NULL,1);
INSERT INTO seed_batch VALUES (169,168,45,SYSDATE-122,SYSDATE+343,85,'Heritage growers',NULL,1);
INSERT INTO seed_batch VALUES (170,169,58,SYSDATE-109,SYSDATE+343,89,'Hill farm',NULL,1);
INSERT INTO seed_batch VALUES (171,170,26,SYSDATE-136,SYSDATE+650,93,'Heritage growers',NULL,1);
INSERT INTO seed_batch VALUES (172,171,55,SYSDATE-101,SYSDATE+377,88,'Heritage growers',NULL,1);
INSERT INTO seed_batch VALUES (173,172,40,SYSDATE-88,SYSDATE+450,89,'Seed lab',NULL,1);
INSERT INTO seed_batch VALUES (174,173,50,SYSDATE-36,SYSDATE+490,94,'Seed lab',NULL,1);
INSERT INTO seed_batch VALUES (175,174,46,SYSDATE-65,SYSDATE+419,88,'Seed lab',NULL,1);
INSERT INTO seed_batch VALUES (176,175,54,SYSDATE-64,SYSDATE+622,94,'Heritage growers',NULL,1);
INSERT INTO seed_batch VALUES (177,176,9,SYSDATE-69,SYSDATE+658,93,'Farmer seed keepers',NULL,1);
INSERT INTO seed_batch VALUES (178,177,8,SYSDATE-35,SYSDATE+901,90,'Hill farm',NULL,1);
INSERT INTO seed_batch VALUES (179,178,11,SYSDATE-79,SYSDATE+659,87,'Hill farm',NULL,1);
INSERT INTO seed_batch VALUES (180,179,14,SYSDATE-81,SYSDATE+520,94,'Farmer seed keepers',NULL,1);
INSERT INTO seed_batch VALUES (181,180,11,SYSDATE-140,SYSDATE+750,92,'Heritage growers',NULL,1);
INSERT INTO seed_batch VALUES (182,181,6,SYSDATE-37,SYSDATE+844,90,'Heritage growers',NULL,1);
INSERT INTO seed_batch VALUES (183,182,880,SYSDATE-176,SYSDATE+331,90,'Madurai farmers coop',NULL,1);
INSERT INTO seed_batch VALUES (184,183,700,SYSDATE-79,SYSDATE+399,93,'Seed lab',NULL,1);
INSERT INTO seed_batch VALUES (185,184,550,SYSDATE-52,SYSDATE+319,95,'Seed lab',NULL,1);
INSERT INTO seed_batch VALUES (186,185,15,SYSDATE-70,SYSDATE+503,89,'Thanjavur farm',NULL,1);
INSERT INTO seed_batch VALUES (187,186,530,SYSDATE-149,SYSDATE+461,96,'Seed lab',NULL,1);
INSERT INTO seed_batch VALUES (188,187,285,SYSDATE-22,SYSDATE+514,94,'Thoothukudi farm',NULL,1);
INSERT INTO seed_batch VALUES (189,188,685,SYSDATE-110,SYSDATE+20,95,'Seed lab',NULL,1);
INSERT INTO seed_batch VALUES (190,189,875,SYSDATE-122,SYSDATE+8,94,'Hill farm',NULL,1);
INSERT INTO seed_batch VALUES (191,190,110,SYSDATE-70,SYSDATE+283,90,'Chennai seed lab',NULL,1);
INSERT INTO seed_batch VALUES (192,191,105,SYSDATE-129,SYSDATE+25,89,'Seed lab',NULL,1);
INSERT INTO seed_batch VALUES (193,192,95,SYSDATE-33,SYSDATE+474,88,'Sivakasi farm',NULL,1);
INSERT INTO seed_batch VALUES (194,193,175,SYSDATE-130,SYSDATE+308,91,'Sivakasi farm',NULL,1);
INSERT INTO seed_batch VALUES (195,194,95,SYSDATE-122,SYSDATE+463,89,'Seed lab',NULL,1);
INSERT INTO seed_batch VALUES (196,195,245,SYSDATE-160,SYSDATE+201,93,'Madurai farmers coop',NULL,1);
INSERT INTO seed_batch VALUES (197,196,160,SYSDATE-35,SYSDATE+348,93,'Sivakasi farm',NULL,1);
INSERT INTO seed_batch VALUES (198,197,170,SYSDATE-129,SYSDATE+339,87,'Seed lab',NULL,1);
INSERT INTO seed_batch VALUES (199,198,35,SYSDATE-61,SYSDATE+345,91,'Seed lab',NULL,1);
INSERT INTO seed_batch VALUES (200,199,43,SYSDATE-100,SYSDATE+381,90,'Farmer seed keepers',NULL,1);
INSERT INTO seed_batch VALUES (201,200,50,SYSDATE-50,SYSDATE+594,91,'Hill farm',NULL,1);
INSERT INTO seed_batch VALUES (202,201,34,SYSDATE-134,SYSDATE+733,94,'Heritage growers',NULL,1);
INSERT INTO seed_batch VALUES (203,202,13,SYSDATE-63,SYSDATE+869,90,'Heritage growers',NULL,1);
INSERT INTO seed_batch VALUES (204,203,12,SYSDATE-82,SYSDATE+581,93,'Farmer seed keepers',NULL,1);
INSERT INTO seed_batch VALUES (205,204,25,SYSDATE-33,SYSDATE+532,94,'Sivakasi farm',NULL,2);
INSERT INTO seed_batch VALUES (206,205,890,SYSDATE-122,SYSDATE+537,88,'Madurai farmers coop',NULL,2);
INSERT INTO seed_batch VALUES (207,206,365,SYSDATE-87,SYSDATE+465,94,'Hill farm',NULL,2);
INSERT INTO seed_batch VALUES (208,207,685,SYSDATE-50,SYSDATE+526,96,'Madurai farmers coop',NULL,2);
INSERT INTO seed_batch VALUES (209,208,855,SYSDATE-31,SYSDATE+366,91,'Seed lab',NULL,2);
INSERT INTO seed_batch VALUES (210,209,520,SYSDATE-179,SYSDATE+439,91,'Coimbatore farm',NULL,2);
INSERT INTO seed_batch VALUES (211,210,675,SYSDATE-170,SYSDATE+443,91,'Hill farm',NULL,2);
INSERT INTO seed_batch VALUES (212,211,335,SYSDATE-165,SYSDATE+359,94,'Thanjavur farm',NULL,2);
INSERT INTO seed_batch VALUES (213,212,745,SYSDATE-164,SYSDATE+507,97,'Hill farm',NULL,2);
INSERT INTO seed_batch VALUES (214,213,145,SYSDATE-168,SYSDATE+264,87,'Chennai seed lab',NULL,2);
INSERT INTO seed_batch VALUES (215,214,185,SYSDATE-135,SYSDATE+448,91,'Chennai seed lab',NULL,2);
INSERT INTO seed_batch VALUES (216,215,280,SYSDATE-26,SYSDATE+481,89,'Coimbatore farm',NULL,2);
INSERT INTO seed_batch VALUES (217,216,145,SYSDATE-75,SYSDATE+289,96,'Sivakasi farm',NULL,2);
INSERT INTO seed_batch VALUES (218,217,285,SYSDATE-150,SYSDATE+328,86,'Hill farm',NULL,2);
INSERT INTO seed_batch VALUES (219,218,215,SYSDATE-163,SYSDATE+174,86,'Thoothukudi farm',NULL,2);
INSERT INTO seed_batch VALUES (220,219,290,SYSDATE-36,SYSDATE+291,90,'Coimbatore farm',NULL,2);
INSERT INTO seed_batch VALUES (221,220,205,SYSDATE-17,SYSDATE+394,88,'Thanjavur farm',NULL,2);
INSERT INTO seed_batch VALUES (222,221,25,SYSDATE-40,SYSDATE+628,85,'Heritage growers',NULL,2);
INSERT INTO seed_batch VALUES (223,222,50,SYSDATE-49,SYSDATE+609,94,'Farmer seed keepers',NULL,2);
INSERT INTO seed_batch VALUES (224,223,25,SYSDATE-27,SYSDATE+684,85,'Heritage growers',NULL,2);
INSERT INTO seed_batch VALUES (225,224,45,SYSDATE-21,SYSDATE+560,86,'Hill farm',NULL,2);
INSERT INTO seed_batch VALUES (226,225,58,SYSDATE-105,SYSDATE+559,89,'Heritage growers',NULL,2);
INSERT INTO seed_batch VALUES (227,226,37,SYSDATE-25,SYSDATE+431,93,'Seed lab',NULL,2);
INSERT INTO seed_batch VALUES (228,227,47,SYSDATE-146,SYSDATE+407,86,'Seed lab',NULL,2);
INSERT INTO seed_batch VALUES (229,228,41,SYSDATE-88,SYSDATE+748,88,'Seed lab',NULL,2);
INSERT INTO seed_batch VALUES (230,229,45,SYSDATE-52,SYSDATE+606,92,'Heritage growers',NULL,2);
INSERT INTO seed_batch VALUES (231,230,47,SYSDATE-33,SYSDATE+751,90,'Heritage growers',NULL,2);
INSERT INTO seed_batch VALUES (232,231,13,SYSDATE-76,SYSDATE+496,89,'Farmer seed keepers',NULL,2);
INSERT INTO seed_batch VALUES (233,232,795,SYSDATE-71,SYSDATE+511,89,'Chennai seed lab',NULL,2);
INSERT INTO seed_batch VALUES (234,233,730,SYSDATE-105,SYSDATE+580,93,'Madurai farmers coop',NULL,2);
INSERT INTO seed_batch VALUES (235,234,205,SYSDATE-66,SYSDATE+407,90,'Sivakasi farm',NULL,2);
INSERT INTO seed_batch VALUES (236,235,265,SYSDATE-161,SYSDATE+325,86,'Coimbatore farm',NULL,2);
INSERT INTO seed_batch VALUES (237,236,235,SYSDATE-101,SYSDATE+438,94,'Madurai farmers coop',NULL,2);
INSERT INTO seed_batch VALUES (238,237,24,SYSDATE-32,SYSDATE+389,92,'Farmer seed keepers',NULL,2);
INSERT INTO seed_batch VALUES (239,238,7,SYSDATE-120,SYSDATE+783,87,'Farmer seed keepers',NULL,2);
INSERT INTO seed_batch VALUES (240,239,450,SYSDATE-146,SYSDATE+465,90,'Madurai farmers coop',NULL,1);
INSERT INTO seed_batch VALUES (241,240,765,SYSDATE-62,SYSDATE+460,88,'Chennai seed lab',NULL,1);
INSERT INTO seed_batch VALUES (242,241,780,SYSDATE-136,SYSDATE+432,92,'Thoothukudi farm',NULL,1);
INSERT INTO seed_batch VALUES (243,242,405,SYSDATE-73,SYSDATE+620,91,'Hill farm',NULL,1);
INSERT INTO seed_batch VALUES (244,243,330,SYSDATE-163,SYSDATE+272,93,'Seed lab',NULL,1);
INSERT INTO seed_batch VALUES (245,244,245,SYSDATE-166,SYSDATE+252,94,'Thoothukudi farm',NULL,1);
INSERT INTO seed_batch VALUES (246,245,120,SYSDATE-120,SYSDATE+224,86,'Hill farm',NULL,1);
INSERT INTO seed_batch VALUES (247,246,120,SYSDATE-78,SYSDATE+463,87,'Sivakasi farm',NULL,1);
INSERT INTO seed_batch VALUES (248,247,220,SYSDATE-19,SYSDATE+340,95,'Madurai farmers coop',NULL,1);
INSERT INTO seed_batch VALUES (249,248,215,SYSDATE-121,SYSDATE+305,86,'Thoothukudi farm',NULL,1);
INSERT INTO seed_batch VALUES (250,249,160,SYSDATE-33,SYSDATE+273,91,'Thoothukudi farm',NULL,1);
INSERT INTO seed_batch VALUES (251,250,260,SYSDATE-25,SYSDATE+439,95,'Hill farm',NULL,1);
INSERT INTO seed_batch VALUES (252,251,170,SYSDATE-27,SYSDATE+285,94,'Coimbatore farm',NULL,1);
INSERT INTO seed_batch VALUES (253,252,105,SYSDATE-74,SYSDATE+240,90,'Coimbatore farm',NULL,1);
INSERT INTO seed_batch VALUES (254,253,46,SYSDATE-49,SYSDATE+851,91,'Farmer seed keepers',NULL,1);
INSERT INTO seed_batch VALUES (255,254,26,SYSDATE-36,SYSDATE+526,95,'Farmer seed keepers',NULL,1);
INSERT INTO seed_batch VALUES (256,255,47,SYSDATE-59,SYSDATE+344,90,'Farmer seed keepers',NULL,1);
INSERT INTO seed_batch VALUES (257,256,54,SYSDATE-52,SYSDATE+458,89,'Farmer seed keepers',NULL,1);
INSERT INTO seed_batch VALUES (258,257,55,SYSDATE-62,SYSDATE+547,89,'Seed lab',NULL,1);
INSERT INTO seed_batch VALUES (259,258,29,SYSDATE-100,SYSDATE+711,87,'Hill farm',NULL,1);
INSERT INTO seed_batch VALUES (260,259,29,SYSDATE-60,SYSDATE+726,89,'Heritage growers',NULL,1);
INSERT INTO seed_batch VALUES (261,260,7,SYSDATE-105,SYSDATE+894,92,'Heritage growers',NULL,1);
INSERT INTO seed_batch VALUES (262,261,14,SYSDATE-59,SYSDATE+893,87,'Heritage growers',NULL,1);
INSERT INTO seed_batch VALUES (263,262,785,SYSDATE-27,SYSDATE+413,93,'Coimbatore farm',NULL,3);
INSERT INTO seed_batch VALUES (264,263,290,SYSDATE-100,SYSDATE+411,95,'Hill farm',NULL,3);
INSERT INTO seed_batch VALUES (265,264,635,SYSDATE-69,SYSDATE+552,92,'Chennai seed lab',NULL,3);
INSERT INTO seed_batch VALUES (266,265,580,SYSDATE-64,SYSDATE+362,94,'Thanjavur farm',NULL,3);
INSERT INTO seed_batch VALUES (267,266,650,SYSDATE-95,SYSDATE+355,97,'Sivakasi farm',NULL,3);
INSERT INTO seed_batch VALUES (268,267,590,SYSDATE-179,SYSDATE+214,94,'Madurai farmers coop',NULL,3);
INSERT INTO seed_batch VALUES (269,268,170,SYSDATE-177,SYSDATE+326,92,'Madurai farmers coop',NULL,3);
INSERT INTO seed_batch VALUES (270,269,130,SYSDATE-143,SYSDATE+407,90,'Hill farm',NULL,3);
INSERT INTO seed_batch VALUES (271,270,270,SYSDATE-152,SYSDATE+185,96,'Coimbatore farm',NULL,3);
INSERT INTO seed_batch VALUES (272,271,95,SYSDATE-43,SYSDATE+409,93,'Thoothukudi farm',NULL,3);
INSERT INTO seed_batch VALUES (273,272,170,SYSDATE-119,SYSDATE+254,88,'Thoothukudi farm',NULL,3);
INSERT INTO seed_batch VALUES (274,273,240,SYSDATE-96,SYSDATE+421,94,'Seed lab',NULL,3);
INSERT INTO seed_batch VALUES (275,274,31,SYSDATE-25,SYSDATE+861,85,'Hill farm',NULL,3);
INSERT INTO seed_batch VALUES (276,275,33,SYSDATE-23,SYSDATE+639,89,'Farmer seed keepers',NULL,3);
INSERT INTO seed_batch VALUES (277,276,20,SYSDATE-22,SYSDATE+702,91,'Heritage growers',NULL,3);
INSERT INTO seed_batch VALUES (278,277,765,SYSDATE-107,SYSDATE+359,95,'Sivakasi farm',NULL,2);
INSERT INTO seed_batch VALUES (279,278,860,SYSDATE-20,SYSDATE+624,88,'Thoothukudi farm',NULL,2);
INSERT INTO seed_batch VALUES (280,279,225,SYSDATE-150,SYSDATE+213,88,'Madurai farmers coop',NULL,2);
INSERT INTO seed_batch VALUES (281,280,90,SYSDATE-27,SYSDATE+551,86,'Seed lab',NULL,2);
INSERT INTO seed_batch VALUES (282,281,100,SYSDATE-25,SYSDATE+406,89,'Chennai seed lab',NULL,2);
INSERT INTO seed_batch VALUES (283,282,195,SYSDATE-37,SYSDATE+402,95,'Thoothukudi farm',NULL,2);
INSERT INTO seed_batch VALUES (284,283,165,SYSDATE-165,SYSDATE+297,87,'Thanjavur farm',NULL,2);
INSERT INTO seed_batch VALUES (285,284,260,SYSDATE-98,SYSDATE+394,91,'Hill farm',NULL,2);
INSERT INTO seed_batch VALUES (286,285,280,SYSDATE-159,SYSDATE+155,93,'Chennai seed lab',NULL,2);
INSERT INTO seed_batch VALUES (287,286,205,SYSDATE-46,SYSDATE+521,95,'Sivakasi farm',NULL,2);
INSERT INTO seed_batch VALUES (288,287,41,SYSDATE-29,SYSDATE+501,92,'Heritage growers',NULL,2);
INSERT INTO seed_batch VALUES (289,288,44,SYSDATE-71,SYSDATE+542,92,'Farmer seed keepers',NULL,2);
INSERT INTO seed_batch VALUES (290,289,48,SYSDATE-100,SYSDATE+644,88,'Heritage growers',NULL,2);
INSERT INTO seed_batch VALUES (291,290,13,SYSDATE-29,SYSDATE+498,91,'Seed lab',NULL,2);
INSERT INTO seed_batch VALUES (292,27,22,SYSDATE-3,SYSDATE+500,94,'Regenerated from batch 28',28,2);
INSERT INTO seed_batch VALUES (293,30,15,SYSDATE-3,SYSDATE+500,94,'Regenerated from batch 31',31,2);
INSERT INTO seed_batch VALUES (294,32,24,SYSDATE-3,SYSDATE+500,94,'Regenerated from batch 33',33,2);
INSERT INTO seed_batch VALUES (295,65,10,SYSDATE-3,SYSDATE+500,94,'Regenerated from batch 66',66,2);
INSERT INTO seed_batch VALUES (296,221,22,SYSDATE-3,SYSDATE+500,94,'Regenerated from batch 222',222,2);
ALTER TRIGGER trg_batch_audit ENABLE;

-- germination tests for batch 4 (shows decay prediction); trigger updates the batch rate
INSERT INTO germination_test VALUES (1,4,SYSDATE-30,90);
INSERT INTO germination_test VALUES (2,4,SYSDATE-2,76);

INSERT INTO companion VALUES (3,4,'COMPANION','Maize and groundnut intercrop well');
INSERT INTO companion VALUES (5,3,'AVOID','Tomato and maize share the fruit borer pest');
INSERT INTO companion VALUES (2,1,'FOLLOWS','Rice-wheat rotation is common');
INSERT INTO companion VALUES (4,3,'FOLLOWS','Groundnut after maize restores soil nitrogen');
INSERT INTO companion VALUES (8,1,'FOLLOWS','Spinach fits a short rabi slot after rice');

-- history for the forecast and feedback demo (inserted directly, so no stock deduction)
INSERT INTO seed_request VALUES (1,3,1,60,'APPROVED',SYSDATE-20);
INSERT INTO seed_request VALUES (2,3,2,90,'APPROVED',SYSDATE-35);
INSERT INTO seed_request VALUES (3,3,3,50,'APPROVED',SYSDATE-10);
INSERT INTO seed_request VALUES (4,3,4,40,'PENDING',SYSDATE-1);
INSERT INTO seed_request VALUES (5,3,1,45,'APPROVED',SYSDATE-50);
INSERT INTO feedback VALUES (1,1,3,1,'Sivakasi',5,'Great yield',SYSDATE-5);
INSERT INTO feedback VALUES (2,3,3,3,'Sivakasi',2,'Poor field germination',SYSDATE-2);

-- extra companion planting and rotation notes
INSERT INTO companion VALUES (211,127,'COMPANION','Basil beside tomato is a common pest-repelling pairing');
INSERT INTO companion VALUES (239,127,'COMPANION','Marigold borders help reduce nematodes and attract pollinators');
INSERT INTO companion VALUES (72,90,'COMPANION','Cowpea fixes nitrogen between maize rows');
INSERT INTO companion VALUES (86,50,'COMPANION','Sorghum with red gram is a traditional intercrop');
INSERT INTO companion VALUES (232,84,'COMPANION','Black gram intercropped in cotton gives extra income');
INSERT INTO companion VALUES (146,144,'COMPANION','Onion and carrot are often grown together to confuse each other's pests');
INSERT INTO companion VALUES (130,103,'COMPANION','Beans between brinjal rows fix nitrogen');
INSERT INTO companion VALUES (49,115,'COMPANION','Millet and groundnut intercrop suits dry lands');
INSERT INTO companion VALUES (130,127,'AVOID','Both share wilt disease and fruit borer');
INSERT INTO companion VALUES (205,127,'AVOID','Fennel is said to stunt tomato growth');
INSERT INTO companion VALUES (146,89,'AVOID','Onion family can slow pea and bean growth');
INSERT INTO companion VALUES (84,10,'FOLLOWS','Black gram is widely grown after rice on residual moisture');
INSERT INTO companion VALUES (85,11,'FOLLOWS','Green gram fits the short gap after rice');
INSERT INTO companion VALUES (110,12,'FOLLOWS','Sesame is a common summer crop after rice');
INSERT INTO companion VALUES (115,10,'FOLLOWS','Groundnut after rice breaks pest cycles');
INSERT INTO companion VALUES (90,72,'FOLLOWS','Cowpea after maize restores soil nitrogen');
INSERT INTO companion VALUES (91,56,'FOLLOWS','Horse gram after ragi uses leftover moisture');
INSERT INTO companion VALUES (262,10,'FOLLOWS','Sunnhemp as green manure improves soil before rice');
INSERT INTO companion VALUES (263,10,'FOLLOWS','Dhaincha green manure adds nitrogen before rice');
COMMIT;
