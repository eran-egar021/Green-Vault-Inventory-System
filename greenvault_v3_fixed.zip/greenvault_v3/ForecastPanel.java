import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.util.*;
import java.util.List;

public class ForecastPanel extends JPanel {
    public ForecastPanel() {
        setLayout(new BorderLayout(0, 10)); setOpaque(false);
        add(Theme.title("Demand Forecast (3-month moving average)"), BorderLayout.NORTH);
        DefaultTableModel m = Theme.model("Seed", "Stock (kg)", "Forecast / month (kg)", "Months of stock left", "Status");
        JTable t = new JTable(m);
        Theme.style(t);
        List<String> labels = new ArrayList<>();
        List<Double> vals = new ArrayList<>();
        try {
            for (Object[] r : Db.query("SELECT s.name, s.total_kg, ROUND(NVL(d.q, 0) / 3, 1), s.reorder_level FROM v_stock s "
                    + "LEFT JOIN (SELECT b.seed_id, SUM(r.qty_kg) q FROM seed_request r JOIN seed_batch b ON b.batch_id = r.batch_id "
                    + "WHERE r.status = 'APPROVED' AND r.request_date >= ADD_MONTHS(TRUNC(SYSDATE, 'MM'), -3) GROUP BY b.seed_id) d "
                    + "ON d.seed_id = s.seed_id ORDER BY s.name")) {
                double stock = Theme.num(r[1]), fc = Theme.num(r[2]), reorder = Theme.num(r[3]);
                Object left = fc > 0 ? (Object) (Math.round(stock / fc * 10) / 10.0) : "-";
                String status = stock < reorder ? "LOW STOCK" : (fc > 0 && stock / fc < 2 ? "Reorder soon" : "OK");
                m.addRow(new Object[]{r[0], stock, fc, left, status});
                labels.add((String) r[0]); vals.add(fc);
            }
        } catch (SQLException e) { Theme.error(this, e); }
        Integer[] idx = new Integer[vals.size()];
        for (int i = 0; i < idx.length; i++) idx[i] = i;
        Arrays.sort(idx, (a, b) -> Double.compare(vals.get(b), vals.get(a)));
        int k = Math.min(10, idx.length);   // top 10 only, so 200+ varieties stay readable
        String[] chartLabels = new String[k];
        double[] chartVals = new double[k];
        for (int i = 0; i < k; i++) { chartLabels[i] = labels.get(idx[i]); chartVals[i] = vals.get(idx[i]); }
        BarChart chart = new BarChart("Top 10 forecast demand per month (kg)", chartLabels, chartVals);
        chart.setPreferredSize(new Dimension(400, 220));
        JPanel bar = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        bar.setOpaque(false);
        bar.add(Theme.button("Export Excel", e -> Exporter.csv(this, t)));
        bar.add(Theme.button("Print / PDF", e -> Exporter.print(this, t)));
        JPanel south = new JPanel(new BorderLayout(0, 8));
        south.setOpaque(false);
        south.add(chart, BorderLayout.CENTER);
        south.add(bar, BorderLayout.SOUTH);
        add(new JScrollPane(t), BorderLayout.CENTER);
        add(south, BorderLayout.SOUTH);
    }
}
