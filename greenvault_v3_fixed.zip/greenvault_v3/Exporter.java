import javax.swing.*;
import javax.swing.table.TableModel;
import java.awt.Component;
import java.awt.print.PrinterException;
import java.io.*;

public class Exporter {
    // Excel-compatible CSV (UTF-8 with BOM so Excel shows special characters correctly)
    public static void csv(Component parent, JTable t) {
        JFileChooser fc = new JFileChooser();
        fc.setSelectedFile(new File("greenvault-report.csv"));
        if (fc.showSaveDialog(parent) != JFileChooser.APPROVE_OPTION) return;
        try (PrintWriter w = new PrintWriter(fc.getSelectedFile(), "UTF-8")) {
            TableModel m = t.getModel();
            w.print("\uFEFF");
            for (int c = 0; c < m.getColumnCount(); c++) w.print((c > 0 ? "," : "") + q(m.getColumnName(c)));
            w.println();
            for (int r = 0; r < m.getRowCount(); r++) {
                for (int c = 0; c < m.getColumnCount(); c++) w.print((c > 0 ? "," : "") + q(String.valueOf(m.getValueAt(r, c))));
                w.println();
            }
        } catch (IOException e) { Theme.error(parent, e); }
    }

    // Opens the print dialog; choose "Save as PDF" / "Microsoft Print to PDF" as the printer
    public static void print(Component parent, JTable t) {
        try { t.print(); } catch (PrinterException e) { Theme.error(parent, e); }
    }

    public static void saveText(Component parent, String fileName, String content) {
        JFileChooser fc = new JFileChooser();
        fc.setSelectedFile(new File(fileName));
        if (fc.showSaveDialog(parent) != JFileChooser.APPROVE_OPTION) return;
        try (PrintWriter w = new PrintWriter(fc.getSelectedFile(), "UTF-8")) { w.print(content); }
        catch (IOException e) { Theme.error(parent, e); }
    }

    private static String q(String s) { return "\"" + s.replace("\"", "\"\"") + "\""; }
}
