// The logged-in user
public class Me {
    public static int id;
    public static String name, role, email;
}
