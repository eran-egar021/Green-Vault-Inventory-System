import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

// Offline QR code generator in plain Java - no zxing, no extra jar.
// Byte mode, error correction level M, versions 1-10 (up to 213 bytes of text).
public class QRService {
    private static final int[] ECC_PER_BLOCK = {0, 10, 16, 26, 18, 24, 16, 18, 22, 22, 26};
    private static final int[] BLOCKS = {0, 1, 1, 1, 2, 2, 4, 4, 4, 5, 5};
    private static final int[][] ALIGN = {null, {}, {6, 18}, {6, 22}, {6, 26}, {6, 30}, {6, 34},
            {6, 22, 38}, {6, 24, 42}, {6, 26, 46}, {6, 28, 50}};

    // ---------- Dialog ----------
    public static void show(Component parent, String title, String text) {
        BufferedImage img = image(encode(text), 8, 4);
        JTextArea area = new JTextArea(text);
        area.setEditable(false); area.setFont(Theme.BASE); area.setBackground(Theme.PACKET);
        area.setBorder(BorderFactory.createEmptyBorder(6, 8, 6, 8));
        JPanel p = new JPanel(new BorderLayout(0, 10));
        p.add(new JLabel(new ImageIcon(img), SwingConstants.CENTER), BorderLayout.CENTER);
        p.add(area, BorderLayout.SOUTH);
        int c = JOptionPane.showOptionDialog(parent, p, title, JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE,
                null, new String[]{"Save as PNG", "Close"}, "Close");
        if (c == 0) save(parent, img);
    }

    private static void save(Component parent, BufferedImage img) {
        JFileChooser fc = new JFileChooser();
        fc.setSelectedFile(new File("batch-qr.png"));
        if (fc.showSaveDialog(parent) != JFileChooser.APPROVE_OPTION) return;
        try {
            File f = fc.getSelectedFile();
            if (!f.getName().toLowerCase().endsWith(".png")) f = new File(f.getPath() + ".png");
            ImageIO.write(img, "png", f);
        } catch (Exception e) { Theme.error(parent, e); }
    }

    public static BufferedImage image(boolean[][] m, int scale, int border) {
        int n = m.length, px = (n + border * 2) * scale;
        BufferedImage img = new BufferedImage(px, px, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = img.createGraphics();
        g.setColor(Color.WHITE); g.fillRect(0, 0, px, px);
        g.setColor(Color.BLACK);
        for (int y = 0; y < n; y++)
            for (int x = 0; x < n; x++)
                if (m[y][x]) g.fillRect((x + border) * scale, (y + border) * scale, scale, scale);
        g.dispose();
        return img;
    }

    // ---------- Encoder ----------
    private static int rawModules(int v) {
        int r = (16 * v + 128) * v + 64;
        if (v >= 2) {
            int n = v / 7 + 2;
            r -= (25 * n - 10) * n - 55;
            if (v >= 7) r -= 36;
        }
        return r;
    }

    private static int dataCodewords(int v) { return rawModules(v) / 8 - ECC_PER_BLOCK[v] * BLOCKS[v]; }

    public static boolean[][] encode(String text) {
        byte[] data = text.getBytes(StandardCharsets.UTF_8);
        int ver = 1;
        while (ver <= 10 && data.length * 8 > dataCodewords(ver) * 8 - 4 - (ver < 10 ? 8 : 16)) ver++;
        if (ver > 10) { ver = 10; data = Arrays.copyOf(data, (dataCodewords(10) * 8 - 20) / 8); } // too long: cut

        List<Integer> bits = new ArrayList<>();
        put(bits, 0x4, 4);
        put(bits, data.length, ver < 10 ? 8 : 16);
        for (byte b : data) put(bits, b & 0xFF, 8);
        int cap = dataCodewords(ver) * 8;
        put(bits, 0, Math.min(4, cap - bits.size()));
        while (bits.size() % 8 != 0) bits.add(0);
        for (int pad = 0xEC; bits.size() < cap; pad ^= 0xEC ^ 0x11) put(bits, pad, 8);
        byte[] dataCw = new byte[cap / 8];
        for (int i = 0; i < bits.size(); i++) dataCw[i >>> 3] |= bits.get(i) << (7 - (i & 7));

        byte[] all = interleave(dataCw, ver);
        int size = ver * 4 + 17;
        boolean[][] mod = new boolean[size][size], fn = new boolean[size][size];
        drawFunctionPatterns(mod, fn, ver, size);
        drawCodewords(mod, fn, all, size);

        int best = 0, bestPenalty = Integer.MAX_VALUE;
        for (int m = 0; m < 8; m++) {
            applyMask(mod, fn, m, size);
            drawFormat(mod, fn, m, size);
            int p = penalty(mod, size);
            if (p < bestPenalty) { bestPenalty = p; best = m; }
            applyMask(mod, fn, m, size); // undo
        }
        applyMask(mod, fn, best, size);
        drawFormat(mod, fn, best, size);
        return mod;
    }

    private static void put(List<Integer> bits, int value, int len) {
        for (int i = len - 1; i >= 0; i--) bits.add((value >>> i) & 1);
    }

    // ---------- Reed-Solomon error correction ----------
    private static int mul(int x, int y) {
        int z = 0;
        for (int i = 7; i >= 0; i--) {
            z = (z << 1) ^ ((z >>> 7) * 0x11D);
            z ^= ((y >>> i) & 1) * x;
        }
        return z;
    }

    private static byte[] divisor(int degree) {
        byte[] r = new byte[degree];
        r[degree - 1] = 1;
        int root = 1;
        for (int i = 0; i < degree; i++) {
            for (int j = 0; j < degree; j++) {
                r[j] = (byte) mul(r[j] & 0xFF, root);
                if (j + 1 < degree) r[j] ^= r[j + 1];
            }
            root = mul(root, 2);
        }
        return r;
    }

    private static byte[] remainder(byte[] data, byte[] div) {
        byte[] r = new byte[div.length];
        for (byte b : data) {
            int factor = (b ^ r[0]) & 0xFF;
            System.arraycopy(r, 1, r, 0, r.length - 1);
            r[r.length - 1] = 0;
            for (int i = 0; i < r.length; i++) r[i] ^= mul(div[i] & 0xFF, factor);
        }
        return r;
    }

    private static byte[] interleave(byte[] dataCw, int ver) {
        int nb = BLOCKS[ver], ecc = ECC_PER_BLOCK[ver], raw = rawModules(ver) / 8;
        int numShort = nb - raw % nb, shortLen = raw / nb;
        byte[][] blocks = new byte[nb][];
        byte[] div = divisor(ecc);
        for (int i = 0, k = 0; i < nb; i++) {
            int len = shortLen - ecc + (i < numShort ? 0 : 1);
            byte[] dat = Arrays.copyOfRange(dataCw, k, k + len);
            k += len;
            byte[] blk = Arrays.copyOf(dat, shortLen + 1);
            System.arraycopy(remainder(dat, div), 0, blk, blk.length - ecc, ecc);
            blocks[i] = blk;
        }
        byte[] out = new byte[raw];
        int k = 0;
        for (int i = 0; i < blocks[0].length; i++)
            for (int j = 0; j < nb; j++)
                if (i != shortLen - ecc || j >= numShort) out[k++] = blocks[j][i];
        return out;
    }

    // ---------- Drawing ----------
    private static void set(boolean[][] mod, boolean[][] fn, int x, int y, boolean dark) {
        mod[y][x] = dark; fn[y][x] = true;
    }

    private static boolean bit(int v, int i) { return ((v >>> i) & 1) != 0; }

    private static void drawFunctionPatterns(boolean[][] mod, boolean[][] fn, int ver, int size) {
        for (int i = 0; i < size; i++) { set(mod, fn, 6, i, i % 2 == 0); set(mod, fn, i, 6, i % 2 == 0); }
        int[][] finders = {{3, 3}, {size - 4, 3}, {3, size - 4}};
        for (int[] f : finders)
            for (int dy = -4; dy <= 4; dy++)
                for (int dx = -4; dx <= 4; dx++) {
                    int x = f[0] + dx, y = f[1] + dy, d = Math.max(Math.abs(dx), Math.abs(dy));
                    if (x >= 0 && x < size && y >= 0 && y < size) set(mod, fn, x, y, d != 2 && d != 4);
                }
        int[] pos = ALIGN[ver];
        int n = pos.length;
        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++) {
                if ((i == 0 && j == 0) || (i == 0 && j == n - 1) || (i == n - 1 && j == 0)) continue;
                for (int dy = -2; dy <= 2; dy++)
                    for (int dx = -2; dx <= 2; dx++)
                        set(mod, fn, pos[i] + dx, pos[j] + dy, Math.max(Math.abs(dx), Math.abs(dy)) != 1);
            }
        drawFormat(mod, fn, 0, size);
        if (ver >= 7) {
            int rem = ver;
            for (int i = 0; i < 12; i++) rem = (rem << 1) ^ ((rem >>> 11) * 0x1F25);
            int bits = (ver << 12) | rem;
            for (int i = 0; i < 18; i++) {
                int a = size - 11 + i % 3, b = i / 3;
                set(mod, fn, a, b, bit(bits, i)); set(mod, fn, b, a, bit(bits, i));
            }
        }
    }

    // Error correction level M has format code 00
    private static void drawFormat(boolean[][] mod, boolean[][] fn, int mask, int size) {
        int data = mask, rem = data;
        for (int i = 0; i < 10; i++) rem = (rem << 1) ^ ((rem >>> 9) * 0x537);
        int bits = ((data << 10) | rem) ^ 0x5412;
        for (int i = 0; i <= 5; i++) set(mod, fn, 8, i, bit(bits, i));
        set(mod, fn, 8, 7, bit(bits, 6)); set(mod, fn, 8, 8, bit(bits, 7)); set(mod, fn, 7, 8, bit(bits, 8));
        for (int i = 9; i < 15; i++) set(mod, fn, 14 - i, 8, bit(bits, i));
        for (int i = 0; i < 8; i++) set(mod, fn, size - 1 - i, 8, bit(bits, i));
        for (int i = 8; i < 15; i++) set(mod, fn, 8, size - 15 + i, bit(bits, i));
        set(mod, fn, 8, size - 8, true);
    }

    private static void drawCodewords(boolean[][] mod, boolean[][] fn, byte[] all, int size) {
        int i = 0;
        for (int right = size - 1; right >= 1; right -= 2) {
            if (right == 6) right = 5;
            for (int vert = 0; vert < size; vert++)
                for (int j = 0; j < 2; j++) {
                    int x = right - j;
                    boolean up = ((right + 1) & 2) == 0;
                    int y = up ? size - 1 - vert : vert;
                    if (!fn[y][x] && i < all.length * 8) { mod[y][x] = bit(all[i >>> 3], 7 - (i & 7)); i++; }
                }
        }
    }

    private static void applyMask(boolean[][] mod, boolean[][] fn, int m, int size) {
        for (int y = 0; y < size; y++)
            for (int x = 0; x < size; x++) {
                boolean inv;
                switch (m) {
                    case 0: inv = (x + y) % 2 == 0; break;
                    case 1: inv = y % 2 == 0; break;
                    case 2: inv = x % 3 == 0; break;
                    case 3: inv = (x + y) % 3 == 0; break;
                    case 4: inv = (x / 3 + y / 2) % 2 == 0; break;
                    case 5: inv = x * y % 2 + x * y % 3 == 0; break;
                    case 6: inv = (x * y % 2 + x * y % 3) % 2 == 0; break;
                    default: inv = ((x + y) % 2 + x * y % 3) % 2 == 0; break;
                }
                if (inv && !fn[y][x]) mod[y][x] ^= true;
            }
    }

    // Standard QR penalty rules 1-4, used to pick the most readable mask
    private static int penalty(boolean[][] m, int n) {
        int p = 0, dark = 0;
        int[] a = {1, 0, 1, 1, 1, 0, 1, 0, 0, 0, 0}, b = {0, 0, 0, 0, 1, 0, 1, 1, 1, 0, 1};
        for (int pass = 0; pass < 2; pass++) {
            for (int i = 0; i < n; i++) {
                int run = 1;
                for (int j = 0; j < n; j++) {
                    boolean cur = pass == 0 ? m[i][j] : m[j][i];
                    if (j > 0) {
                        boolean prev = pass == 0 ? m[i][j - 1] : m[j - 1][i];
                        if (cur == prev) { run++; if (run == 5) p += 3; else if (run > 5) p++; } else run = 1;
                    }
                    if (j + 11 <= n) {
                        boolean ma = true, mb = true;
                        for (int k = 0; k < 11; k++) {
                            boolean v = pass == 0 ? m[i][j + k] : m[j + k][i];
                            if (v != (a[k] == 1)) ma = false;
                            if (v != (b[k] == 1)) mb = false;
                        }
                        if (ma || mb) p += 40;
                    }
                }
            }
        }
        for (int y = 0; y < n; y++)
            for (int x = 0; x < n; x++) {
                if (m[y][x]) dark++;
                if (x + 1 < n && y + 1 < n && m[y][x] == m[y][x + 1] && m[y][x] == m[y + 1][x] && m[y][x] == m[y + 1][x + 1]) p += 3;
            }
        int total = n * n;
        p += ((Math.abs(dark * 20 - total * 10) + total - 1) / total - 1) * 10;
        return p;
    }
}
