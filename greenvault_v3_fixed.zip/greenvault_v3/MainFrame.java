import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.function.Supplier;

// Role-based shell: header + card-grid home. Each tile opens its screen with a Back to home button.
public class MainFrame extends JFrame {
    private final JPanel content = new JPanel(new BorderLayout());

    public MainFrame() {
        setTitle("GreenVault - " + Me.role + ": " + Me.name);
        setSize(1120, 740); setMinimumSize(new Dimension(900, 640));
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        content.setBackground(Theme.BG);
        add(header(), BorderLayout.NORTH);
        add(content, BorderLayout.CENTER);
        home();
    }

    private JPanel header() {
        JPanel h = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g0) {
                Graphics2D g = (Graphics2D) g0.create();
                g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g.setColor(Theme.DARK); g.fillRect(0, 0, getWidth(), getHeight());
                HomePanel.sprouts(g, getWidth() - 150, getHeight() - 6, 7);
                g.setColor(Theme.OCHRE); g.fillRect(0, getHeight() - 4, getWidth(), 4);
                g.dispose();
            }
        };
        h.setPreferredSize(new Dimension(100, 90));
        h.setBorder(new EmptyBorder(12, 24, 10, 24));

        JLabel brand = new JLabel("GreenVault", Theme.logo(44), SwingConstants.LEFT);
        brand.setForeground(Theme.PACKET); brand.setFont(new Font("Georgia", Font.BOLD, 28));
        brand.setIconTextGap(12);
        JLabel who = new JLabel(Me.name + " (" + Me.role + ")");
        who.setForeground(new Color(0xD9CFA9));
        JPanel left = new JPanel();
        left.setOpaque(false); left.setLayout(new BoxLayout(left, BoxLayout.Y_AXIS));
        left.add(brand); left.add(who);
        h.add(left, BorderLayout.WEST);

        JButton out = new JButton("Log out");
        out.setBackground(Theme.OCHRE); out.setForeground(Theme.TEXT); out.setFont(Theme.BOLD);
        out.setFocusPainted(false); out.setOpaque(true); out.setBorder(new EmptyBorder(8, 18, 8, 18));
        out.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        out.addActionListener(e -> { dispose(); new WelcomeFrame().setVisible(true); });
        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 12));
        right.setOpaque(false); right.add(out);
        h.add(right, BorderLayout.EAST);
        return h;
    }

    private void home() {
        boolean staff = !Me.role.equals("CLIENT");
        HomePanel p = new HomePanel();
        p.addTile("Overview", "Stock, alerts and charts", HomePanel.Icon.LEAF, Theme.DARK, () -> open(DashboardPanel::new));
        p.addTile("Find Seed", "Match seeds to your land", HomePanel.Icon.SEARCH, Theme.MOSS, () -> open(FindSeedPanel::new));
        if (staff) p.addTile("Batches", "Stock, expiry, germination", HomePanel.Icon.BOX, Theme.KRAFT, () -> open(BatchPanel::new));
        p.addTile(staff ? "Requests" : "My Requests", staff ? "Approve or reject" : "Track your requests",
                HomePanel.Icon.CLIPBOARD, Theme.OCHRE, () -> open(RequestsPanel::new));
        if (staff) {
            p.addTile("Storage", "Vault temperature and humidity", HomePanel.Icon.THERMO, Theme.CLAY, () -> open(StoragePanel::new));
            p.addTile("Forecast", "Demand and months of stock", HomePanel.Icon.TREND, Theme.MID, () -> open(ForecastPanel::new));
        }
        if (Me.role.equals("ADMIN"))
            p.addTile("Audit Log", "Who did what, and when", HomePanel.Icon.LIST, Theme.KRAFT, () -> open(AuditPanel::new));
        swap(p);
    }

    // A fresh panel each time, so data is always up to date
    private void open(Supplier<JPanel> screen) {
        JPanel wrap = new JPanel(new BorderLayout(0, 8));
        wrap.setBackground(Theme.BG);
        wrap.setBorder(new EmptyBorder(14, 24, 18, 24));
        JButton back = Theme.button("< Back to home", e -> home());
        back.setBackground(Theme.KRAFT);
        JPanel bar = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        bar.setOpaque(false); bar.add(back);
        wrap.add(bar, BorderLayout.NORTH);
        wrap.add(screen.get(), BorderLayout.CENTER);
        swap(wrap);
    }

    private void swap(JComponent c) {
        content.removeAll();
        content.add(c, BorderLayout.CENTER);
        content.revalidate(); content.repaint();
    }
}
