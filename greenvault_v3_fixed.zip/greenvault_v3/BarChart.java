import javax.swing.*;
import java.awt.*;

// Small custom bar chart (no external chart library needed)
public class BarChart extends JPanel {
    private final String title;
    private final String[] labels;
    private final double[] values;

    public BarChart(String title, String[] labels, double[] values) {
        this.title = title; this.labels = labels; this.values = values;
        setBackground(Theme.PACKET); setBorder(BorderFactory.createLineBorder(Theme.LINE));
        setPreferredSize(new Dimension(420, 250));
    }

    @Override protected void paintComponent(Graphics g0) {
        super.paintComponent(g0);
        Graphics2D g = (Graphics2D) g0;
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setColor(Theme.DARK); g.setFont(Theme.BOLD); g.drawString(title, 14, 22);
        int n = values.length;
        if (n == 0) return;
        double max = 1;
        for (double v : values) max = Math.max(max, v);
        int left = 14, top = 40, bottom = getHeight() - 30, slot = (getWidth() - 28) / n, bar = Math.max(8, slot - 12);
        g.setFont(Theme.BASE.deriveFont(11f));
        FontMetrics fm = g.getFontMetrics();
        for (int i = 0; i < n; i++) {
            int h = (int) ((bottom - top) * values[i] / max), x = left + i * slot + (slot - bar) / 2;
            g.setColor(i % 2 == 0 ? Theme.MID : Theme.OCHRE); g.fillRoundRect(x, bottom - h, bar, h, 6, 6);
            g.setColor(Theme.TEXT);
            String val = String.valueOf((int) values[i]);
            g.drawString(val, x + (bar - fm.stringWidth(val)) / 2, bottom - h - 4);
            String lab = labels[i].length() > 9 ? labels[i].substring(0, 8) + "." : labels[i];
            g.drawString(lab, x + (bar - fm.stringWidth(lab)) / 2, bottom + 16);
        }
    }
}
